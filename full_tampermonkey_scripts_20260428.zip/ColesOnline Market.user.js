// ==UserScript==
// @name         ColesOnline Market
// @namespace    http://tampermonkey.net/
// @version      2024-11-20
// @description  try to take over the world!
// @author       You
// @match        https://engage.oracle.com/515e50?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=oracle.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var query = window.location.search.substring(1);
    var pair = query.split('&');

    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        //alert("hello");
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "TriggerColesWPPage",
                "ora.z_email": pair[0].split("=")[1].replaceAll("%20"," "),
                "ora.z_category": pair[1].split("=")[1].replaceAll("%20"," ")
            }
        });
    };
    document.head.appendChild(script);
    sessionStorage.clear();

    // Your code here...
})();