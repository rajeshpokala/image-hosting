// ==UserScript==
// @name         maxlifeinsurance
// @namespace    http://tampermonkey.net/
// @version      2024-10-01
// @description  try to take over the world!
// @author       You
// @match        https://www.maxlifeinsurance.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=maxlifeinsurance.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

        function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="maxlifeinsurance";
        var title = "maxlifeinsurance";
        var eventid = Date.now();

        var email="kumar.rp1215@gmail.com";
        var age = document.querySelector("#bread-crumb-wrapper-container > main > div > div.jsx-3153974416.w-full.page-container > div > div > div:nth-child(11) > div > div > div.jsx-393521747.calculator-container > form > div > div > section > div.jsx-3815273442.form-container > div.w-full.lg\\:mb-5.pt-4.lg\\:pt-0.px-2.mb-4.lg\\:mb-10.lg\\:px-3.px-0 > div > div > div.jsx-734674607.bubble.absolute.px-3.py-1.bg-red-200.mb-5.bg-gradient-to-b.from-blue-400.to-blue-600.inline-block.text-white.rounded-md.font-family-bold.text-sm").innerText.replaceAll("yrs","");
        var tag = "term-insurance-plans";
        var lifeCoverAmt = "2";
        var premiumAmount = document.querySelector("#bread-crumb-wrapper-container > main > div > div.jsx-3153974416.w-full.page-container > div > div > div:nth-child(11) > div > div > div.jsx-393521747.calculator-container > form > div > div > section > div.jsx-3815273442.form-container > div:nth-child(5) > div > div.jsx-1630703313.flex.space-x-12.lg\\:justify-center.justify-between.px-4.lg\\:px-2.items-center.self-stretch.opacity-1 > div > div.jsx-1630703313.text-amount").innerText.replaceAll("/month*6","").replaceAll("₹ ","");

        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSuppMAXLIFE",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_email": email,
                    "ora.z_age": age,
                    "ora.z_tag": tag,
                    "ora.z_lifeCoverAmt": lifeCoverAmt,
                    "ora.z_premiumAmount": premiumAmount,
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "maxlifeinsurance",
                "wt.ti": "maxlifeinsurance",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventMAXLIFE",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

    // Your code here...
})();