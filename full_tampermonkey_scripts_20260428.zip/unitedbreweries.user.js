// ==UserScript==
// @name         unitedbreweries
// @namespace    http://tampermonkey.net/
// @version      2024-07-16
// @description  try to take over the world!
// @author       You
// @match        http://demo.orapse.com/LP=2820
// @icon         https://www.google.com/s2/favicons?sz=64&domain=unitedbreweries.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //alert("start");
    const form_int = document.getElementById("form1367");

    form_int.addEventListener('submit', (event) => {
        // Prevent default form submission
        //event.preventDefault();
        // Your code here
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var email = document.querySelector("#fe10502").value;
        var cookie = "unitedbreweries";
        var title = "unitedbreweries";
        var firstname = document.querySelector("#fe10500").value;
        var lastname = document.querySelector("#fe10501").value;
        var mobilenumber = document.querySelector("#fe10505").value;
        var interestarea = document.querySelector("#fe10507").value;
        var message = document.querySelector("#fe10503").value;

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                   "ora.z_eventname": "unitedbreweries",
                   "ora.z_email": email,
                   "ora.z_firstname": firstname,
                   "ora.z_lastname": lastname,
                   "ora.z_mobilenumber": mobilenumber,
                   "ora.z_interestarea": interestarea,
                   "ora.z_message": message,
                  }]
              };
        //console.log(payload);
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        alert("Form submitted!");
        return true;
    });
})();