// ==UserScript==
// @name         ACT NewConnection
// @namespace    http://tampermonkey.net/
// @version      2024-10-09
// @description  try to take over the world!
// @author       You
// @match        https://www.actcorp.in/new-connection*
// @icon         https://www.actcorp.in/sites/default/files/favicon_1.png
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    window.ondblclick = function() {captureFunction()};
    //const element = document.getElementById("edit-submit");
    //element.addEventListener("click", captureFunction);


    function captureFunction() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var eventid = Date.now();
        var Name = document.querySelector("#edit-name").value;
        var Phone = document.querySelector("#edit-phone-number").value;
        var City = document.querySelector("#city-proof > span > span.selection > span").innerText;
        var Address = document.querySelector("#place-address-autocomplete").value;
        var Company = document.querySelector("#edit-company-name").value;
        var Email = document.querySelector("#edit-email").value;
        var Premises = document.querySelector('input[name="multi_story_option"]:checked')?.value;

        alert("Data Captured");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "ACT_NewConnection_request",
                    "ora.z_tag": "New Connection",
                    "ora.z_Email": "veerubravo@gmail.com",
                    "ora.z_Name": Name,
                    "ora.z_City": City,
                    "ora.z_Phone": Phone,
                    "ora.z_Address": Address,
                    "ora.z_Company": Company,
                    "ora.z_Premises": Premises,
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var payload = {
               "events": [{
                     "ora.z_eventname": "Trigger_NewConnection",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "veerubravo@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

})();