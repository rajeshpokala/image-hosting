// ==UserScript==
// @name         equitasbank CC page
// @namespace    http://tampermonkey.net/
// @version      2024-10-02
// @description  try to take over the world!
// @author       You
// @match        https://corp.equitasbank.com/HDFCBANK-creditcard
// @icon         https://www.google.com/s2/favicons?sz=64&domain=equitasbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //const anchorTag = document.getElementsByClassName('nav-link link-actblue mainheading text-center');
    //localStorage.setItem('ccardType',"");

    window.ondblclick = function() {captureFunction()};

    function captureFunction(){
    //window.addEventListener('beforeunload', function(e) {
        const anchorTag = document.getElementsByTagName('a');
        alert("hello");

        for (let i = 0; i < anchorTag.length; i++) {
            if(anchorTag[i].innerText.indexOf("HDFC Bank Credit Card") > 0 && anchorTag[i].className.indexOf("active") > 0){
                console.log(anchorTag[i].innerText);
                console.log(anchorTag[i].className);
                localStorage.setItem('ccardType', anchorTag[i].innerText.substr(8,anchorTag[i].innerText.indexOf("–") - 9));
                sessionStorage.setItem("ccType", anchorTag[i].innerText.substr(8,anchorTag[i].innerText.indexOf("–") - 9));

            }
        }


    //});
        //setTimeout(triggerFunction, 5000);
    }

    function triggerFunction(){
        window.location.href = "https://equitasbank.com/";
    }

    // Your code here...
})();