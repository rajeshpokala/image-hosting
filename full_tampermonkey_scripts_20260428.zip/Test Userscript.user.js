// ==UserScript==
// @name         Test Userscript
// @namespace    http://tampermonkey.net/
// @version      2025-01-15
// @description  try to take over the world!
// @author       You
// @match        https://www.genertel.it/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=genertel.it
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var cType = "Simple";
    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/c30c97282f3d4f0d2daafcd03087ec9a/js/genertel_demo/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "TriggerGenertelHP",
                "ora.z_tag": "Home Page",
                "ora.z_ctype": cType
            }
        });
    };
    document.head.appendChild(script);

})();