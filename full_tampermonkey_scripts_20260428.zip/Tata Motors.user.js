// ==UserScript==
// @name         Tata Motors
// @namespace    http://tampermonkey.net/
// @version      2025-09-24
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://cars.tatamotors.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tatamotors.com
// @require      https://raw.githubusercontent.com/rajeshpokala/jscode/refs/heads/main/addWPscript.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

    window.addEventListener("load", () => {
        if(window.location.href.startsWith("https://cars.tatamotors.com/book-test-drive/standard") == true){
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;
            script.onload = () => {
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerWPtatamotors"
                    }
                });
            };
            document.head.appendChild(script);
            sessionStorage.clear();

            window.ondblclick = function() {showCountdown();};
         }
        if(window.location.href == "https://cars.tatamotors.com/"){
            alert("here");
            triggerwp();
        }
        if(window.location.href.startsWith("https://cars.tatamotors.com/?em=") == true){
            alert("here1");
            triggerwp();
        }
    });

    function capturecardetails() {
        localStorage.vimg = document.querySelector("#tml-container-91d76f28a2 > div > div.select-vehicle.aem-GridColumn--tablet--10.aem-GridColumn--phone--12.aem-GridColumn.aem-GridColumn--default--7 > div > div > div.car-configuration > div:nth-child(2) > div.car-image.car-info-section > picture > img").src.replaceAll("?$SV-276-108-D$&fit=fit&fmt=webp","");
        localStorage.vmodel = document.querySelector("#tml-container-91d76f28a2 > div > div.select-vehicle.aem-GridColumn--tablet--10.aem-GridColumn--phone--12.aem-GridColumn.aem-GridColumn--default--7 > div > div > div.car-configuration > div:nth-child(2) > div.car-model.car-info-section > div.model-dropdown.vehicle-dropdown").innerText;
        localStorage.vfuel = document.querySelector("#tml-container-91d76f28a2 > div > div.select-vehicle.aem-GridColumn--tablet--10.aem-GridColumn--phone--12.aem-GridColumn.aem-GridColumn--default--7 > div > div > div.car-configuration > div:nth-child(3) > div.fuel.car-info-section > div.fuel-dropdown.vehicle-dropdown").innerText;
        localStorage.vtransmission = document.querySelector("#tml-container-91d76f28a2 > div > div.select-vehicle.aem-GridColumn--tablet--10.aem-GridColumn--phone--12.aem-GridColumn.aem-GridColumn--default--7 > div > div > div.car-configuration > div:nth-child(3) > div.transmission.car-info-section > div.transmission-dropdown.vehicle-dropdown").innerText;
        localStorage.getvehicle = document.querySelector("#transport-form > div.pick-up-vehicle-form > div > div > div.radio-button").innerText;
        localStorage.dlocation = document.querySelector("#select2-dealer-cities-dropdown-container").innerText;
        localStorage.dname = document.querySelector("#container0 > div.flex-item-right > div.radio-button__label-title > h6 > div").innerText;
        localStorage.pageLocurl = window.location.href;

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var chkdat = localStorage.vimg;
        var chkeml = localStorage.email_addr;

        script.onload = () => {
            // Code to execute after the script has loaded
            if(chkdat != null){
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggertataHomePage",
                        "ora.z_tag": "Home Page",
                        "wt.dcsvid": chkeml,
                        "user.prodimageurl": localStorage.vimg,
                        "user.prodname": localStorage.vmodel,
                        "user.prodtype": localStorage.vfuel,
                        "ora.z_vtransmission": localStorage.vtransmission,
                        "ora.z_getvehicle": localStorage.getvehicle,
                        "user.dealerloc": localStorage.dlocation,
                        "user.dealername": localStorage.dname,
                        "user.desturl": localStorage.pageLocurl
                    }
                });
            }
        };
        document.head.appendChild(script);

    }

    function triggerwp() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var chkdat = localStorage.vimg;
        var chkeml = localStorage.email_addr;
        var em = getQueryVariable('em');

        if (em == null){em = localStorage.email_addr;}

        script.onload = () => {
            // Code to execute after the script has loaded
            if(chkdat != null){
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggertataHomePage",
                        "wt.dcsvid": em,
                        "ora.z_tag": "Home Page"
                    }
                });
            } else if(em != null){
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggertataHomePage",
                        "wt.dcsvid": em,
                        "ora.z_tag": "Home Page"
                    }
                });
            }
        };
        document.head.appendChild(script);
    }

    function getQueryVariable(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        console.log('Query variable %s not found', variable);
    }

    function showCountdown() {
         if (document.getElementById("countdown")) return;

        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 10s";

        countdownDiv.style.fontSize = "20px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #ccc";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "30%";
        countdownDiv.style.right = "20px";
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 10;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.innerText = "Data Captured";
                //countdownDiv.remove(); // remove the div after countdown
                capturecardetails();
            }
        }, 1000);
    }

    // Your code ends here...

})();