// ==UserScript==
// @name         cardekho home page
// @namespace    http://tampermonkey.net/
// @version      2025-06-17
// @description  try to take over the world!
// @author       You
// @match        https://www.cardekho.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=cardekho.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.recData = {
    "recommendations": [
        {
            "Product ID": "SKU1",
            "Name": localStorage.pname,
			"Material": localStorage.vehicleDotList,
			"Thumb Image URL": "https://images10.gaadi.com/usedcar_image/4603712/original/processed_e146718a99bca6e9cf46cb3acae41577.jpg?imwidth=640",
			"Image URL": localStorage.pimg,
			"Page URL": "https://www.cardekho.com/used-cars+in",
            "Price": localStorage.pprice,
            "Formatted Price": null
        },
        {
            "Product ID": "SKU2",
            "Name": localStorage.pname0,
			"Material": "35,000 kms • Petrol • Automatic • 1st Owner",
			"Thumb Image URL": "https://images10.gaadi.com/usedcar_image/4549326/original/processed_2ce44302371d1150b17189119943b4e9.jpg?imwidth=420",
            "Image URL": localStorage.pimg0,
			"Page URL": "https://www.cardekho.com/used-cars+in",
            "Price": localStorage.pprice0,
            "Formatted Price": null
        },
        {
            "Product ID": "SKU3",
            "Name": localStorage.pname1,
			"Material": "35,000 kms • Petrol • Automatic • 1st Owner",
			"Thumb Image URL": "https://images10.gaadi.com/usedcar_image/4617424/original/processed_86661b413cd452100d156223e0c0b914.jpg?imwidth=420",
            "Image URL": localStorage.pimg1,
			"Page URL": "https://www.cardekho.com/used-cars+in",
            "Price": localStorage.pprice1,
            "Formatted Price": null
        }
    ]
}

    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;
    var chkdat = localStorage.pimg;

    script.onload = () => {
        // Code to execute after the script has loaded
        if(chkdat != null){
            console.log('Script loaded successfully:');
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerHomePageCAR",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_tag": "Home Page",
                    "ora.z_pimg": localStorage.pimg,
                    "ora.z_pimg0": localStorage.pimg0,
                    "ora.z_pimg1": localStorage.pimg1,
                    "ora.z_pname": localStorage.pname,
                    "ora.z_pname0": localStorage.pname0,
                    "ora.z_pname1": localStorage.pname1,
                    "ora.z_pprice": localStorage.pprice,
                    "ora.z_pprice0": localStorage.pprice0,
                    "ora.z_pprice1": localStorage.pprice1,
                    "ora.z_recommendStr": localStorage.recommendStr,
                    "ora.z_vehicleDotList": localStorage.vehicleDotList,
                    "ora.z_pageloc": localStorage.pageLocurl
                }
            });
        }
    };
    document.head.appendChild(script);



    // Your code here...
})();