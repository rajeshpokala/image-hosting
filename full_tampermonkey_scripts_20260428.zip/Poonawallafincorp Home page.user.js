// ==UserScript==
// @name         Poonawallafincorp Home page
// @namespace    http://tampermonkey.net/
// @version      2024-09-26
// @description  try to take over the world!
// @author       You
// @match        https://poonawallafincorp.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=poonawallafincorp.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
//        function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerHomePage",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_tag": "Home Page",
                    "ora.z_city": "Chennai"
                }
            });
        };
        document.head.appendChild(script);
  //  }

    // your code end here...
})();