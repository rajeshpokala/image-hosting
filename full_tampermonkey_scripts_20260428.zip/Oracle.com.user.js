// ==UserScript==
// @name         Oracle.com
// @namespace    http://tampermonkey.net/
// @version      2024-10-16
// @description  try to take over the world!
// @author       You
// @match        https://www.oracle.com/in/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=oracle.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    document.getElementsByTagName('body')[0].onscroll = (e) => {
        //console.log(e);
        let scrper = (document.documentElement.scrollTop + document.body.scrollTop) / (document.documentElement.scrollHeight - document.documentElement.clientHeight) * 100;
        console.log(Math.round(scrper));

        //if (Math.round(scrper) == 50){
        //    alert("50%");
        //}
    };
    //nEW
    const bd = document.getElementsByTagName('body');
    bd[0].onwheel = () => {
        //console.log(e);
        let scrper = (document.documentElement.scrollTop + document.body.scrollTop) / (document.documentElement.scrollHeight - document.documentElement.clientHeight) * 100;
        console.log(Math.round(scrper));

        if (Math.round(scrper) >= 50 && Math.round(scrper) <= 56){
            alert("Customer scrolled up to " + Math.round(scrper) + " %");
            captureFunction();
        }
    };

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var eventid = Date.now();

        //generic settings
        var email="kumar.rp1215@gmail.com";
        var cookie="shriram";
        var title = "shriram";
        var loantype = "Two Wheeler Loan";
        var loanval = 10000;
        var roi = 9;
        var totalinst = 2000;
        var monEMI = 1000;


        var payload = {
            "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
                "domain": "www.shriramfinance.in",
            },
            "events": [{
                "ora.z_eventname": "TriggerORACLE",
                "ora.z_email": email,
                "ora.z_loantype": loantype,
                "ora.z_totalinst": totalinst,
                "ora.z_loannemi": monEMI,
                "ora.z_twlintrest": roi,
                "ora.z_twltenure": 12,
                "ora.z_twlamount": loanval,
                "ora.z_source":"Google",
                "ora.z_srcPage":"EMI Calculator",
                "ora.z_vistorID":"73e886e9-9f5e-c870-9768-e4269d3f7222",
                "ora.z_deviceType":"Android",
                "ora.z_eventid": eventid
            }]
        };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        //setTimeout(triggerFunction, 12000);
    }
   // Your code here...

})();