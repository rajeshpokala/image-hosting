// ==UserScript==
// @name         anb.com Userscript
// @namespace    http://tampermonkey.net/
// @version      2026-01-12
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://anb.com.sa/web/anb*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=anb.com.sa
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.addEventListener("load", () => {
        if(window.location.href.startsWith("https://anb.com.sa/web/anb/apply-now-credit-card") == true){
            //alert("hello 1");
            window.ondblclick = function() { capturedetails(); };
        }

        if(window.location.href == "https://anb.com.sa/web/anb/credit-cards"){
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "anbccpage"
                    }
                });
            }
            document.head.appendChild(script);
        }

        if(window.location.href == "https://anb.com.sa/web/anb"){
            //alert("hello");
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "anbcreditcard"
                    }
                });
            }
            document.head.appendChild(script);
        }
    });

    function capturedetails() {
        const annualFeeRow = [...document.querySelectorAll('.row.pt-3')].find(row => row.innerText.toLowerCase().includes('annual fee'));

        let cclimit = [...document.querySelectorAll('.h3.text-center')].find(el => el.innerText.includes('credit limit'));
        let cclimitamt = cclimit.innerText.replaceAll("Your credit limit is ","");
        let annualFee = annualFeeRow?.querySelector('.col-md-3')?.innerText.trim();
        let cardname = document.querySelector("#result > div > div > div > div.subtitle.font-weight-semi-bold.pt-4").innerText;
        let imgcard = document.querySelector("#result > div > div > div > img").src;

        localStorage.setItem('cclimit', cclimitamt);
        localStorage.setItem('annualFee', annualFee);
        localStorage.setItem('cardname', cardname);
        localStorage.setItem('imgcard', imgcard);
    }
    // Your code here...
})();