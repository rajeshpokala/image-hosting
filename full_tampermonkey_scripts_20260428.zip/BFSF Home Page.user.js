// ==UserScript==
// @name         BFSF Home Page
// @namespace    http://tampermonkey.net/
// @version      2024-10-15
// @description  try to take over the world!
// @author       You
// @match        C:/PROJECT/BFSF/nWxhqEG5sKJm.com/index.html
// @icon         https://www.google.com/s2/favicons?sz=64&domain=undefined.
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var loanamt = localStorage.loanAmtRequested;
    if(loanamt != null){
        triggerWP();
    }

    function triggerWP() {
alert("good");
        var loanamnt = localStorage.loanAmtRequested;
		var monEMI = localStorage.monEMI;
		var roi = localStorage.roi;
		var tenure = localStorage.tenure;
        var email = localStorage.email;
        var firstname = localStorage.firstname;

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            //alert("hello");
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerWPEquitas",
                    "ora.z_email": email,
                    "ora.z_firstname": firstname,
                    "ora.z_loanAmtRequested": loanamnt,
                    "ora.z_monEMI": monEMI,
                    "ora.z_roi": roi,
                    "ora.z_tenure": tenure
                }
            });
        };
        document.head.appendChild(script);
        sessionStorage.clear();
    }
    // Your code here...
})();