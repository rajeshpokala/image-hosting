// ==UserScript==
// @name         KotatBank eligibility
// @namespace    http://tampermonkey.net/
// @version      2025-02-16
// @description  try to take over the world!
// @author       You
// @match        https://www.kotak.com/en/personal-banking/loans/personal-loan/eligibility.html
// @icon         https://www.google.com/s2/favicons?sz=64&domain=kotak.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {
        console.log("Data captured");
        localStorage.loanAmtRequested = document.querySelector("#plan-works-1 > div.sip_container > div.sip_right > div.right_section1 > div > div > h3 > span.right_amount").innerHTML;
        localStorage.monEMI = document.querySelector("#plan-works-1 > div.sip_container > div.sip_right > div.goal-invest-container > div > div.goal-amt-invest-ctn > span.goal-amt-invest").innerText;
        localStorage.tenure = document.querySelector("#plan-works-1 > div.sip_container > div.sip_left.tab-hide-pt > div:nth-child(3) > div.left_section1 > div.rage_div > input.rangedata").value;
    }
    // Your code here...

})();