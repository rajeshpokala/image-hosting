// ==UserScript==
// @name         shriramfinance
// @namespace    http://tampermonkey.net/
// @version      2024-02-28
// @description  try to take over the world!
// @author       You
// @match        https://www.shriramfinance.in/two-wheeler-loan-calculator
// @icon         https://www.google.com/s2/favicons?sz=64&domain=shriramfinance.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //window.ondblclick = function() {captureFunction()};
    const bd = document.getElementsByTagName('body');
    bd[0].onwheel = () => {
        //console.log(e);
        let scrper = (document.documentElement.scrollTop + document.body.scrollTop) / (document.documentElement.scrollHeight - document.documentElement.clientHeight) * 100;
        console.log(Math.round(scrper));

        if (Math.round(scrper) >= 50 && Math.round(scrper) <= 56){
            alert("Customer scrolled up to " + Math.round(scrper) + " %");
            captureFunction();
        }
    };

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var eventid = Date.now();

        //generic settings
        var email="kumar.rp1215@gmail.com";
        var cookie="shriram";
        var title = "shriram";
        var loantype = "Two Wheeler Loan";
        var loanval = document.querySelector("#loan_amount").value.replaceAll(",","");
        var roi = document.querySelector("#Interest\\ rate\\ applicable").value;
        var totalinst = document.querySelector("#fd_online_calculator > div > div > app-loan-calculator > div > div > div:nth-child(2) > div > div.calculator__amount.mb-lg-3 > div.calculator__amountRow.calculator__lastAmountRow.d-flex.justify-content-between > p").innerText.replaceAll(",","");
        var monEMI = document.querySelector("#fd_online_calculator > div > div > app-loan-calculator > div > div > div:nth-child(2) > div > div.calculator__amount.mb-lg-3 > div.calculator__totalRow.d-flex.justify-content-between > p:nth-child(2)").innerText.replaceAll(",","");


        var payload = {
            "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
                "domain": "www.shriramfinance.in",
            },
            "events": [{
                "ora.z_eventname": "TriggerSuppSHR",
                "ora.z_email": email,
                "ora.z_loantype": loantype,
                "ora.z_totalinst": totalinst,
                "ora.z_loannemi": monEMI.replaceAll("₹ ",""),
                "ora.z_twlintrest": roi,
                "ora.z_twltenure": document.querySelector("#Tenure\\ up\\ to").value,
                "ora.z_twlamount": loanval,
                "ora.z_source":"Google",
                "ora.z_srcPage":"EMI Calculator",
                "ora.z_vistorID":"73e886e9-9f5e-c870-9768-e4269d3f7222",
                "ora.z_deviceType":"Android",
                "ora.z_eventid": eventid
            }]
        };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
            "static": {
                "wt.co_f": "SHRIRAM",
                "wt.ti": "SHRIRAM",
            },
            "events": [{
                "ora.z_eventname": "TriggerEventSHR",
                "ora.z_email": "kumar.rp1215@gmail.com"
            }]
        };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
})();