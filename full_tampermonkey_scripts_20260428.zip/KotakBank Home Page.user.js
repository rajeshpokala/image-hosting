// ==UserScript==
// @name         KotakBank Home Page
// @namespace    http://tampermonkey.net/
// @version      2025-02-16
// @description  try to take over the world!
// @author       You
// @match        https://www.kotak.com/en/home.html
// @icon         https://www.google.com/s2/favicons?sz=64&domain=kotak.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var loanamt = localStorage.loanAmtRequested;
    if(loanamt != null){
        triggerWP();
    }
    function triggerWP() {
        //alert("good");
        var loanamnt = localStorage.loanAmtRequested;
        var monEMI = localStorage.monEMI;
        var tenure = localStorage.tenure;

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            //alert("hello");
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "WP_Kotakhomepage",
                    "ora.z_wploanAmtReq": loanamnt,
                    "ora.z_wpmonEMI": monEMI,
                    "ora.z_wptenure": tenure
                }
            });
        };
        document.head.appendChild(script);
        sessionStorage.clear();
    }
    // Your code end here...
})();