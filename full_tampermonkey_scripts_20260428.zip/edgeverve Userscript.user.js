// ==UserScript==
// @name         edgeverve Userscript
// @namespace    http://tampermonkey.net/
// @version      2025-11-28
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.edgeverve.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=edgeverve.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var cseg = localStorage.getItem("segmentName");
    if(cseg != null){ //alert(cseg);
        callWP(cseg);
    }
    const STORAGE_KEY = 'edgeverve_segment_choice';

    if (document.getElementById('ev-segment-toggle')) return;

    // styles
    const css = `
    #ev-segment-toggle {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 2147483647;
      background: linear-gradient(180deg, #ffffff, #f7fbff);
      border: 1px solid rgba(11,95,165,0.12);
      box-shadow: 0 6px 18px rgba(11,95,165,0.14);
      border-radius: 10px;
      padding: 10px 12px;
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      color: #07243a;
      min-width: 160px;
    }
    #ev-segment-toggle h4 {
      margin: 0 0 8px 0;
      font-size: 15px;
      font-weight: 700;
      letter-spacing: -0.2px;
    }
    #ev-segment-toggle .ev-options {
      display:flex;
      gap:8px;
      align-items:center;
      justify-content:space-between;
    }
    #ev-segment-toggle label {
      display:inline-flex;
      align-items:center;
      gap:6px;
      cursor:pointer;
      font-size:13px;
      color:#08324a;
    }
    #ev-segment-toggle input[type="radio"] {
      width:14px;
      height:14px;
    }
    #ev-segment-toggle .ev-help {
      margin-top:8px;
      font-size:11px;
      color:#4a6b87;
    }
    #ev-segment-toggle .ev-close {
      position:absolute;
      top:4px;
      right:4px;
      background:transparent;
      border:none;
      color:#4a6b87;
      cursor:pointer;
      font-size:14px;
    }
    @media (max-width:480px){
      #ev-segment-toggle { right:10px; bottom:10px; min-width:140px; padding:8px; }
      #ev-segment-toggle h4 { font-size:12px; }
    }
  `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);

    // build panel
    const panel = document.createElement('div');
    panel.id = 'ev-segment-toggle';
    panel.setAttribute('role', 'region');
    panel.setAttribute('aria-label', 'Segment toggle');
    panel.innerHTML = `
    <button class="ev-close" aria-label="Close toggle">✕</button>
    <h4>Choose segment</h4>
    <div class="ev-options" role="radiogroup" aria-label="Segment options">
      <label title="Financial">
        <input type="radio" name="evSegment" value="financial" />
        <span>Financial</span>
      </label>
      <label title="Telecom">
        <input type="radio" name="evSegment" value="telecom" />
        <span>Telecom</span>
      </label>
    </div>
    <div class="ev-help">Change will refresh the page</div>
  `;
    document.body.appendChild(panel);

    const radioFinancial = panel.querySelector('input[value="financial"]');
    const radioTelecom = panel.querySelector('input[value="telecom"]');
    const closeBtn = panel.querySelector('.ev-close');

    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'financial') radioFinancial.checked = true;
    else if (saved === 'telecom') radioTelecom.checked = true;

    function onChange(e) {
        try {
            const val = e.target.value;
            // store choice
            localStorage.setItem(STORAGE_KEY, val);
            radioFinancial.disabled = true;
            radioTelecom.disabled = true;
            //alert(val);
            localStorage.setItem("segmentName", val);
            callWP(val);
            setTimeout(function() {location.reload()},1000);

        } catch (err) {
            console.error('Segment toggle error', err);
        }
    }

    radioFinancial.addEventListener('change', onChange);
    radioTelecom.addEventListener('change', onChange);

    closeBtn.addEventListener('click', () => {
        panel.style.display = 'none';
    });

    window.addEventListener('keydown', (ev) => {
        if (ev.ctrlKey && (ev.key === 'm' || ev.key === 'M')) {
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        }
    });

    function callWP(cseg){
        //alert(cseg);
        function delete_cookie( name, path, domain ) {
            document.cookie = name + "=" +
                ((path) ? ";path="+path:"")+
                ((domain)?";domain="+domain:"") +
                ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
        }

        delete_cookie("ORA_FPC", "/", ".edgeverve.com");
        delete_cookie("FPC", "/", ".edgeverve.com");
        localStorage.removeItem("ORA_COOK_STORE");

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var eventid = Date.now();
        script.onload = () => {
            console.log('Script loaded successfully:');
            ORA.view({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggeredgeverveHomeWP",
                    "ora.z_email": "rajesh.kumar.pokala@oracle.com",
                    "ora.z_segmentname": cseg,
                    "ora.z_usrcity": "Chennai",
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        //sessionStorage.clear(); "wt.dl": 0,
    }
    // Your code here...
})();