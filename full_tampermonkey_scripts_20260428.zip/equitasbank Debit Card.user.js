// ==UserScript==
// @name         equitasbank Debit Card
// @namespace    http://tampermonkey.net/
// @version      2024-10-03
// @description  try to take over the world!
// @author       You
// @match        https://equitasbank.com/personal-banking/pay/debit-cards/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=equitasbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    document.addEventListener('click', function(event) {
        const clickedElement = event.target;
        var dctype = "";

        // Do something with the clicked element
        //console.log("Clicked element:", clickedElement);
        const anchorTag = clickedElement.getElementsByTagName('a');
        //console.log("Clicked element classname:", anchorTag[0].href);
        dctype = anchorTag[0].href.replaceAll("https://equitasbank.com/apply-now/?type=","");
        console.log(dctype);
        localStorage.setItem('ccardType', dctype.replaceAll("-",""));

    });
    // Your code here...

})();