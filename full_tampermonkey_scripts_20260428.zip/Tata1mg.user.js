// ==UserScript==
// @name         Tata1mg
// @namespace    http://tampermonkey.net/
// @version      2024-09-17
// @description  try to take over the world!
// @author       You
// @match        https://www.1mg.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=1mg.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    // Your code here...


    window.addEventListener('beforeunload', function(e) {
            if(window.location.href.substring(window.location.href.lastIndexOf("/")+1) == "labs"){
                var email = JSON.stringify(dataLayer[0].email);
                var uname = JSON.stringify(dataLayer[0].uname.substr(3));
                localStorage.setItem('email', email);
                localStorage.setItem('uname', uname);
            }
        //return false;
    });
  //  window.ondblclick = function() {
  //      if(window.location.href.substring(window.location.href.lastIndexOf("/")+1) == "labs")
  //      {triggerWP()}
  //      else if(window.location.href.substring(window.location.href.lastIndexOf("/")+1) == "cart")
  //      {captureFunction()}};


    function onload(fn) {
        if (document.readyState === 'complete') fn();
        else window.addEventListener("load", fn);
    }
    if(location.pathname === '/labs'){
        var prodname = localStorage.pname;
        if(prodname != null){
            //alert(prodname);
            onload(triggerWP);
        }
    }

function triggerWP() {

     var pnameid = localStorage.pname;
     var ppriceid = localStorage.pprice;
     const script = document.createElement('script');
  script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
  script.async = true;

  script.onload = () => {
    // Code to execute after the script has loaded
    console.log('Script loaded successfully:');
       //alert("hello");
          ORA.click({
			"sendSessionInfo": true,
			"data": {
				  "ora.z_eventname": "TriggerWPTata1mg",
				  "ora.z_email": "kumar.rp1215@gmail.com",
				  "ora.z_pname": pnameid,
                  "ora.z_pprice": ppriceid,
				}
		});
  };
document.head.appendChild(script);
sessionStorage.clear();
}

    window.ondblclick = function() {if(window.location.href.substring(window.location.href.lastIndexOf("/")+1) == "cart"){captureFunction()}};

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var email=localStorage.email.replaceAll('"',"");
        var name = localStorage.uname;
        //var mobilenumber = document.querySelector("#edit-callback-mobile-number").value;
        var pname = document.querySelector(".smallSemiBold.ListOfTestOnCart__overflow__hNr5y").innerText;
        localStorage.setItem('pname', pname);
        var pprice = document.querySelector(".bodyRegular.textPrimary").innerText.substr(1);
        localStorage.setItem('pprice', pprice);
        var totalamt = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(3) > div:nth-child(3) > div > div.marginTop-8.col-8.flex.justifyBetween.l5SemiBold > div:nth-child(2)").innerText.substr(1);
        var pimg0 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(1) > div > div.flexColumn > a > div > div.flex.col-11 > img").src;
        var loypoints = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(3) > div:nth-child(5) > div:nth-child(1) > div.flex.alignCenter.justifyBetween.marginTop-8 > div.xSmallRegular.textSecondary").innerText;

        //frequently booked
        var fpname1 = document.querySelector(".ListOfTestCarousel__card__nNjJ2 > div.bodySemiBold").innerText;
        var fpdesc1 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(1) > div > a > div > div.flexColumn.marginTop-8.ListOfTestCarousel__card__nNjJ2 > div.smallRegular").innerText;
        var fpimg1 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(1) > div > a > div > img").src;

        var fpname2 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(2) > div > a > div > div.flexColumn.marginTop-8.ListOfTestCarousel__card__nNjJ2 > div.bodySemiBold").innerText;
        var fpdesc2 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(2) > div > a > div > div.flexColumn.marginTop-8.ListOfTestCarousel__card__nNjJ2 > div.smallRegular").innerText;
        var fpimg2 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(2) > div > a > div > img").src;

        var fpname3 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(3) > div > a > div > div.flexColumn.marginTop-8.ListOfTestCarousel__card__nNjJ2 > div.bodySemiBold").innerText;
        var fpdesc3 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(3) > div > a > div > div.flexColumn.marginTop-8.ListOfTestCarousel__card__nNjJ2 > div.smallRegular").innerText;
        var fpimg3 = document.querySelector("#app > div:nth-child(2) > div.page-container > div > div:nth-child(1) > div:nth-child(3) > div > div.marginTop-16 > div > div.flex.Carousel__slider__aMvfx > div:nth-child(3) > div > a > div > img").src;

        var cookie="tata1mg";
        var title = "tata1mg";
        var eventid = Date.now();

        //var pprice = localStorage.lsloanAmtRequested;
        var tag = window.location.href.substring(window.location.href.lastIndexOf("/")+1);
        //var monEMI = localStorage.lsemi.replaceAll(",","");
        //var roi = localStorage.lsroi;
        //var tenure = localStorage.lstenure;

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppTATA1mg",
                     "ora.z_email": email,
                     "ora.z_pname": pname,
                     "ora.z_pprice": pprice,
                     "ora.z_totalamt": totalamt,
                     "ora.z_pimg0": pimg0,
                     "ora.z_loypoints": loypoints,
                     "ora.z_tag": tag,
                     "ora.z_categories": "Labs",
                     "ora.z_eventid": eventid,
                     "ora.z_fpname1": fpname1,
                     "ora.z_fpdesc1": fpdesc1,
                     "ora.z_fpimg1": fpimg1,
                     "ora.z_fpname2": fpname2,
                     "ora.z_fpdesc2": fpdesc2,
                     "ora.z_fpimg2": fpimg2,
                     "ora.z_fpname3": fpname3,
                     "ora.z_fpdesc3": fpdesc3,
                     "ora.z_fpimg3": fpimg3
                  }]
              };
        //console.log(payload);
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var emailid = localStorage.email.replaceAll('"',"");
        var payload = {
                "static": {
                "wt.co_f": "tata1mg",
                "wt.ti": "tata1mg",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventTata1mg",
                     "ora.z_tag_id": "1",
                     "ora.z_email": emailid
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

})();