// ==UserScript==
// @name         rblbank cc page
// @namespace    http://tampermonkey.net/
// @version      2025-04-25
// @description  try to take over the world!
// @author       You
// @match        https://www.rblbank.com/personal-banking/cards/credit-cards
// @icon         https://www.google.com/s2/favicons?sz=64&domain=rblbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerVernacularRBLCCPage",
                    "ora.z_lang": "Hindi"
                }
            });
        };
        document.head.appendChild(script);

    localStorage.cctype = null;

    document.addEventListener("click", function(event) {

        if (event.target.alt == "Shoprite Credit Card") {
            alert("Data Captured");
            console.log("You clicked:", event.target.alt);
            localStorage.cctype = "icon";
    }
  });

    // Your code here...

})();