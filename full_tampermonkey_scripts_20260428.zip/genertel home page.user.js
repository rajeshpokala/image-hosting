// ==UserScript==
// @name         genertel home page
// @namespace    http://tampermonkey.net/
// @version      2025-01-07
// @description  try to take over the world!
// @author       You
// @match        https://www.genertel.it/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=genertel.it
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var cType = localStorage.ctype;
    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/c30c97282f3d4f0d2daafcd03087ec9a/js/genertel_demo/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var eventid = Date.now();

        //generic settings
        var email="kumar.rp1215+165065@gmail.com";
        var CustomerID="1_165065";
        var title = "eventdata";


        var payload = {
            "static": {
                "wt.ti": title,
                "domain": "www.oracle.come"
            },
            "events": [{
                "ora.z_eventname": "TriggerGenHomePage",
                "ora.z_tag": "Home Page",
                "ora.z_ctype": cType
            }]
        };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
    };
    document.head.appendChild(script);

    // Your code here...
})();