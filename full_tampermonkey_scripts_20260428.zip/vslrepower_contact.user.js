// ==UserScript==
// @name         vslrepower_contact
// @namespace    http://tampermonkey.net/
// @version      2024-03-26
// @description  try to take over the world!
// @author       You
// @match        https://www.vslrepower.com/contact-us
// @icon         https://www.google.com/s2/favicons?sz=64&domain=vslrepower.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        //alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings

        var cookie="vslrepower";
        var title = "vslrepower";
        var email=localStorage.email;
        var projecttype = document.querySelector("body > div.page-wrapper > section > div > div > div > form > div:nth-child(8) > div:nth-child(1) > div > select").value;

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "PushData2IQ",
                     "ora.z_email": email,
                     "ora.z_projecttype": projecttype
                  }]
              };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "applicamobilenumion/json");
        xmlhttp.send(JSON.stringify(payload));
    }

})();