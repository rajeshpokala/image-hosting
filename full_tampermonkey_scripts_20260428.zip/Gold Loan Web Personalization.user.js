// ==UserScript==
// @name         Gold Loan Web Personalization
// @namespace    http://tampermonkey.net/
// @version      2024-10-07
// @description  try to take over the world!
// @author       You
// @match        https://www.muthootfinance.com/
// @icon         https://www.muthootfinance.com/sites/default/files/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var ltype = localStorage.ltype;
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerGoldloanPage",
                    "ora.z_email": "veerubravo@gmail.com",
                    "ora.z_tag": ltype
                }
            });
        };
        document.head.appendChild(script);
    // Your code here...
})();