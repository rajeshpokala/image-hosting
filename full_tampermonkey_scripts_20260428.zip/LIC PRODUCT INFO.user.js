// ==UserScript==
// @name         LIC PRODUCT INFO
// @namespace    http://tampermonkey.net/
// @version      2024-05-22
// @description  try to take over the world!
// @author       You
// @match        https://ebiz.licindia.in/D2CPM/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=licindia.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var cookie="LIC";
        var title = "LIC";
        var email="kumar.rp1215@gmail.com";
        var mnumber = 8939953499;
        var plan_name = "Endowment Plans";
        var policy_img = "https://ecms.licindia.in/eCMS/getfilesrc/1580537673SG9PU2a5w0he70s";
        var product_name = document.getElementsByClassName('x-title-text x-title-text-M_dapanel x-title-item')[0].innerText;
        var product_summary = "";
        var payment_mode = "";
        var min_age_limit = "8 Years (completed)";
        var max_age_limit = "75 years (nearer birthday)";
        var policy_maturity_benefit = "";
        var cnt = document.getElementsByClassName('x-container lic-productplancontent x-container-default')[0].firstElementChild.firstElementChild.childElementCount;

        for (let i = 0; i < cnt - 10; i++) {
            var val = document.getElementsByClassName('x-container lic-productplancontent x-container-default')[0].firstElementChild.firstElementChild.children[i].innerText;
            if (val.toLowerCase() == "product summary") {
                product_summary = document.getElementsByClassName('x-container lic-productplancontent x-container-default')[0].firstElementChild.firstElementChild.children[i+1].innerText;
            } else if (val.toLowerCase().includes("premium payment mode")) {
                payment_mode = document.getElementsByClassName('x-container lic-productplancontent x-container-default')[0].firstElementChild.firstElementChild.children[i+1].innerText;
            } else if (val.toLowerCase().includes("maturity benefit")) {
                policy_maturity_benefit = document.getElementsByClassName('x-container lic-productplancontent x-container-default')[0].firstElementChild.firstElementChild.children[i+1].innerText;
            } else {
                let greeting = "Good evening";
            }
        }

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppLIC",
                     "ora.z_email": email,
                     "ora.z_mnumber": mnumber,
                     "ora.z_plan_name": plan_name,
                     "ora.z_policy_img": policy_img,
                     "ora.z_product_name": product_name,
                     "ora.z_product_summary": product_summary,
                     "ora.z_payment_mode": payment_mode,
                     "ora.z_min_age_limit": min_age_limit,
                     "ora.z_max_age_limit": max_age_limit,
                     "ora.z_policy_maturity_benefit": policy_maturity_benefit
                  }]
              };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));

        setTimeout(triggerFunction, 12000);
    }
    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "LIC",
                "wt.ti": "LIC",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventLIC",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
})();