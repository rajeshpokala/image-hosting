// ==UserScript==
// @name         rblbank home page
// @namespace    http://tampermonkey.net/
// @version      2025-04-25
// @description  try to take over the world!
// @author       You
// @match        https://www.rblbank.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=rblbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var cctype = localStorage.cctype;
    if(cctype != null){
        triggerWP();
    }
    function triggerWP() {
        //alert("good");
        var cctype = localStorage.cctype;
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            //alert("hello");
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "WP_rblhomepage"
                }
            });
        };
        document.head.appendChild(script);
        sessionStorage.clear();
    }
    // Your code here...

})();