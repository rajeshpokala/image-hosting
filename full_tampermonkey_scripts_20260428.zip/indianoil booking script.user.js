// ==UserScript==
// @name         indianoil booking script
// @namespace    http://tampermonkey.net/
// @version      2025-04-30
// @description  try to take over the world!
// @author       You
// @match        https://cx.indianoil.in/webcenter/portal/LPG/pages_dashboard*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=indianoil.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        window.ondblclick = function() {showCountdown()};
    var email="kumar.rp1215@gmail.com";

    function showCountdown() {
        // Avoid creating multiple timers
        if (document.getElementById("countdown")) return;

        // Create the countdown div with inline styles
        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 15s";

        // Apply inline styles
        countdownDiv.style.fontSize = "24px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #ccc";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "50%";
        countdownDiv.style.right = "20px";
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 15;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.innerText = "Data Captured";
                //countdownDiv.remove(); // remove the div after countdown
                captureFunction();
            }
        }, 1000);
    }


        function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="indianoil";
        var title = "indianoil";
        var eventid = Date.now();

        var phone="8939953499";
        var CylinderRequest=document.querySelector("#T\\:oc_1015787353r1IOZ41\\:soc1\\:\\:content").title;
        var tag = "Booking";
        var DeliveryType = "Preferred Delivery";
        var Weekday=document.querySelector("#T\\:oc_1015787353r1IOZ41\\:soc2\\:\\:content").title;
        var timeslot=document.querySelector("#T\\:oc_1015787353r1IOZ41\\:soc3\\:\\:content").title;
        var consumerid=document.querySelector("#T\\:oc_1015787353r1IOZ41\\:pgl43 > span.font-size14.light-font.font-normal.show").innerText;
        var distributor=document.querySelector("#T\\:oc_1015787353r1IOZ41\\:ot1").innerText;

        //alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSupIOCL",
                    "ora.z_phone": phone,
                    "ora.z_email": email,
                    "ora.z_CylinderRequest": CylinderRequest,
                    "ora.z_tag": tag,
                    "ora.z_DeliveryType": DeliveryType,
                    "ora.z_Weekday": Weekday,
                    "ora.z_timeslot": timeslot,
                    "ora.z_consumerid": consumerid,
                    "ora.z_distributor": distributor,
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        //var email=document.querySelector("#Email_address").value;

        var payload = {
                "static": {
                "wt.co_f": "careinsurance",
                "wt.ti": "careinsurance",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventIOCL",
                     "ora.z_tag_id": "1",
                     "ora.z_email": email
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // Your code end here...
})();