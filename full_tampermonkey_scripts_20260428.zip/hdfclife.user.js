// ==UserScript==
// @name         hdfclife
// @namespace    http://tampermonkey.net/
// @version      2025-09-03
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.hdfclife.com/term-insurance-plans*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=hdfclife.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
let formSelections;
    // Your code here...
    window.addEventListener('load', () => {

        formSelections = {
            nri: null,
            gender: null,
            tobacco: null
        };

        function setSelection(type, value) {
            formSelections[type] = value;
            //console.log(`[Captured] ${type}: ${value}`);
            console.log("test" + formSelections);
        }

         document.querySelectorAll("#nriBannerForm span").forEach(el => {
            el.addEventListener("click", function () {
                setSelection("nri", this.textContent.trim());
            });
        });

         document.querySelectorAll("#gen span.customFormRadioFlex").forEach(el => {
            el.addEventListener("click", function () {
                setSelection("gender", this.textContent.trim());
            });
        });

         document.querySelectorAll("#smoker span").forEach(el => {
            el.addEventListener("click", function () {
                setSelection("tobacco", this.textContent.trim());
            });
        });

    });
    //Rajesh
    window.ondblclick = function() {
        //captureFunction()
        console.log(formSelections.nri);
    };

    function captureFunction() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        //var cookie="muthootfinance";
        //var title = "muthootfinance";
        var eventid = Date.now();
        var fnameBannerForm = document.querySelector("#fnameBannerForm").value;
        var no_nriBannerForm = formSelections.nri;
        var maleBannerForm = formSelections.gender;
        var noBannerForm = formSelections.tobacco;
        var dateBirth = document.querySelector("#dateBirth").value;
        var annualIncome = document.querySelector("#annualIncome").value;
        var phone = document.querySelector("#phone").value;
        var email = document.querySelector("#email").value;
        var consent = document.querySelector("#agree-checkbox").value;

        alert("Data Captured");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerHDFCLife",
                    "ora.z_tag": "HDFCLife_Quote_dropoff",
                    "ora.z_fnameBannerForm": fnameBannerForm,
                    "ora.z_no_nriBannerForm": no_nriBannerForm,
                    "ora.z_maleBannerForm": maleBannerForm,
                    "ora.z_noBannerForm": noBannerForm,
                    "ora.z_dateBirth": dateBirth,
                    "ora.z_annualIncome": annualIncome,
                    "ora.z_phone": phone,
                    "ora.z_email": email,
                    "ora.z_consent": consent,
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        //setTimeout(triggerFunction, 24000);
    }
    // Your code here...

})();