// ==UserScript==
// @name         lenskart
// @namespace    http://tampermonkey.net/
// @version      2025-08-17
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.lenskart.com/eyeglasses*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=lenskart.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // Run initially
    addOutOfStockLabels();

     window.ondblclick = function() {showCountdown();};

    function showCountdown() {
        // Avoid creating multiple timers
        alert("here");
        if (document.getElementById("countdown")) return;

        // Create the countdown div with inline styles
        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 5s";

        // Apply inline styles
        countdownDiv.style.fontSize = "24px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.color = "red";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #ccc";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "50%";
        countdownDiv.style.right = "20px";
        //countdownDiv.style.top = "20px"; // push from top
        //countdownDiv.style.left = "50%"; // move to center
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 5;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.innerText = "Data Captured";
                //countdownDiv.remove(); // remove the div after countdown
                captureFunction();
            }
        }, 1000);
    }

  async function captureFunction() {
        console.log('Script loaded successfully:');
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var eventid = 0;

        for (let i = 0; i < dataLayer.length; i++) {
            eventid = Date.now();
            if (dataLayer[i].event == "add_to_wishlist"){
                //alert(i);
                var payload = {
                    "static": {
                        "wt.co_f": "lenskart",
                        "wt.ti": "lenskar",
                    },
                    "events": [{
                        "ora.z_eventname": "TriggerLenskartUnity",
                        "ora.z_email": "kumar.rp1215@gmail.com",
                        "ora.z_phone": "8939953499",
                        "ora.z_tag": "add_to_wishlist",
                        "ora.z_item_brand": dataLayer[i].ecommerce.items[0].item_brand,
                        "ora.z_item_category": dataLayer[i].ecommerce.items[0].item_category,
                        "ora.z_item_price": dataLayer[i].ecommerce.items[0].price,
                        "ora.z_item_name": dataLayer[i].ecommerce.items[0].item_name,
                        "ora.z_item_id": dataLayer[i].ecommerce.items[0].item_id,
                        "ora.z_productid": "INVS_" + dataLayer[i].ecommerce.items[0].item_id,
                        "ora.z_custid": "1_139598",
                        "ora.z_status": "Out of Stock",
                        "ora.z_eventid": eventid
                    }]
                };

                xmlhttp1.open("POST", url1);
                xmlhttp1.setRequestHeader("Content-Type", "application/json");
                xmlhttp1.send(JSON.stringify(payload));
                await sleep(3000);
            }
        }
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }



    function addOutOfStockLabels() {
        // Select all wishlist containers (usually button or div with wishlist class)
        let wishlistContainers = document.querySelectorAll('[class*="wishlist"]');

        wishlistContainers.forEach((container, index) => {
            // Only for alternate items (every 2nd: 1, 3, 5...)
            if (index % 2 === 1) {
                // Avoid duplicate insertion
                if (!container.parentElement.querySelector('.out-of-stock-label')) {
                    let label = document.createElement("span");
                    label.innerText = "Out of Stock";
                    label.className = "out-of-stock-label";
                    label.style.color = "red";
                    label.style.fontWeight = "bold";
                    label.style.marginLeft = "8px";
                    container.parentElement.appendChild(label);
                }
            }
        });
    }


    // Run again if user scrolls / products lazy load
    let observer = new MutationObserver(() => {
        addOutOfStockLabels();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    // Your code here...
})();