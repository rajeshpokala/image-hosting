// ==UserScript==
// @name         Care Insu Popup
// @namespace    http://tampermonkey.net/
// @version      2025-12-17
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.careinsurance.com/rhicl/login/register
// @icon         https://www.google.com/s2/favicons?sz=64&domain=careinsurance.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    // Show only once per session
    if (sessionStorage.getItem('ci_popup_shown')) return;
    sessionStorage.setItem('ci_popup_shown', 'true');

    // Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'ci-backdrop';
    backdrop.style.cssText = `
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.45);
    display:flex;
    align-items:center;
    justify-content:center;
    z-index:9999;
  `;

    // Modal
    const modal = document.createElement('div');
    modal.style.cssText = `
    width:90%;
    max-width:420px;
    background:#ffffff;
    border-radius:8px;
    box-shadow:0 12px 40px rgba(0,0,0,0.2);
    padding:24px 22px 26px;
    font-family:Arial,Helvetica,sans-serif;
    position:relative;
  `;

    modal.innerHTML = `
    <button id="ci-close" style="
      position:absolute;
      top:14px;
      right:14px;
      background:none;
      border:none;
      font-size:18px;
      cursor:pointer;
      color:#333;
    ">✕</button>

    <h2 style="
      margin:0 0 18px;
      font-size:22px;
      font-weight:600;
      color:#11699e;
    ">Log In</h2>

    <label style="font-size:14px;color:#a7a9ac;">Mobile Number</label>
    <input id="ci-mobile" type="tel" maxlength="50"
      placeholder="Enter mobile number"
      style="
        width:100%;
        height:44px;
        padding:10px 12px;
        margin:6px 0 14px;
        border:1px solid #d6d6d6;
        border-radius:4px;
        font-size:14px;
        box-sizing:border-box;
        outline:none;
      " />

    <label style="font-size:14px;color:#a7a9ac;">Select Insurance Type</label>
    <select id="ci-type"
      style="
        width:100%;
        height:44px;
        padding:10px 12px;
        margin:6px 0 20px;
        border:1px solid #d6d6d6;
        border-radius:4px;
        font-size:14px;
        box-sizing:border-box;
        background:#fff;
        outline:none;
      ">
      <option value="">Select</option>
      <option value="health">Health Insurance</option>
      <option value="travel">Travel Insurance</option>
    </select>

    <button id="ci-submit" style="
      width:100%;
      height:46px;
      background:#ffd618;
      border:none;
      border-radius:4px;
      color:#231f20;
      font-size:15px;
      font-weight:600;
      cursor:pointer;
    ">Submit</button>
  `;

    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    // Close handlers
    document.getElementById('ci-close').onclick = () => backdrop.remove();
    backdrop.onclick = e => { if (e.target === backdrop) backdrop.remove(); };

    // Input focus styling
    ['ci-mobile', 'ci-type'].forEach(id => {
        const el = document.getElementById(id);
        el.onfocus = () => el.style.borderColor = '#1e88e5';
        el.onblur = () => el.style.borderColor = '#d6d6d6';
    });

    // Submit handler
    document.getElementById('ci-submit').onclick = () => {
        const mobile = document.getElementById('ci-mobile').value.trim();
        const type = document.getElementById('ci-type').value;

        //if (!/^[6-9]\\d{9}$/.test(mobile)) {
        //    alert('Please enter a valid 10-digit mobile number');
        //    return;
        //}
        if (!type) {
            alert('Please select insurance type');
            return;
        } else{
            /* const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggercareAppEvent",
                        "wt.dcsvid": mobile,
                        "user.phone": mobile,
                        "user.category": type
                    }
                });
            };
            document.head.appendChild(script);*/
           /* fetch('https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true', {
                method: 'POST',
                body: JSON.stringify({
                    "static": {
                        "wt.dcsvid": mobile,
                        "user.phone": mobile,
                        "user.category": type,
                        "ora.z_eventname": "WP_rajeshdata",
                        "ora.z_cid": mobile
                    },
                    "events": [{
                        "dcsuri": location.href,
                        "wt.dl": "0"
                    }]
                })
            })
                .then(response => response.json())
                .then(body => console.log(body));*/

            setTimeout(function() {

                const script = document.createElement('script');
                script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
                script.async = true;

                script.onload = () => {
                    setTimeout(ORA.click,2000);
                    // Code to execute after the script has loaded
                    console.log('Script loaded successfully:test');
                    ORA.click({
                        "sendSessionInfo": true,
                        "data": {
                            "ora.z_eventname": "WP_rajeshdata",
                            "wt.dcsvid": mobile,
                            "ora.z_cid": mobile,
                            "user.category": type,
                            "wt.dl": "0"
                        }
                    });
                };

                document.head.appendChild(script);
            },100);

            /*fetch('https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true', {
                method: 'POST',
                body: JSON.stringify({
                    "events": [{
                        "dcsuri": "/",
                        "wt.dcsvid": "RAJESH_SFTP_1-1",
                        "user.phone": mobile,
                        "user.category": type
                    }]
                })
            })
                .then(response => response.json())
                .then(body => console.log(body));*/

        }

        //console.log('CareInsurance Popup Data:', { mobile, type });

        backdrop.remove();
    };
    // Your code here...

})();