// ==UserScript==
// @name         test script
// @namespace    http://tampermonkey.net/
// @version      2025-08-15
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

   // fetch(`https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true`, {
   //         method: 'POST',
   //         body: JSON.stringify({
     //           "static": {
       //             "wt.co_f": "a0bb4e09-7da1-4565-8b63-f216c82f2737"
         //       },
           //     "events": [{
             //       "dcsuri": null,
             //       "wt.dl": "0",
            //        "wt.ets": parseInt(new Date()/1000, 10),
           //         "bid": "1"
         //       }]
       //     })
     //   })

            const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            //alert("hello");
            ORA.click({
                "sendSessionInfo": true,
                "static":
                {
                    "wt.co_f":"a0bb4e09-7da1-4565-8b63-f216c82f2737"
                },
                "data": {
                    "ora.z_eventname": "WP_carehomepage",
                    "bid": "1"
                },
                "events": [{
                  "dcsuri": null,
                  "wt.dl": "1",
                  "wt.ets": parseInt(new Date()/1000, 10),
                  "bid": "1"
                }]
            });
        };
        document.head.appendChild(script);


})();