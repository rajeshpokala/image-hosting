// ==UserScript==
// @name         CapriHomeLoans Calculator
// @namespace    http://tampermonkey.net/
// @version      2024-06-13
// @description  try to take over the world!
// @author       You
// @match        https://www.caprihomeloans.com/loan-eligibility-calculator
// @icon         https://www.google.com/s2/favicons?sz=64&domain=caprihomeloans.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var email="kumar.rp1215@gmail.com";
        var cookie="caprihomeloans";
        var title = "caprihomeloans";
        var loanAmtRequested = document.querySelector("#loanAmount").value.replaceAll(",","");
        var monthlyIncome = document.querySelector("#monthlyIncome").value;
        var monEMI = document.querySelector("#output > span:nth-child(5)").innerHTML.substring(2);
        var roi = document.querySelector("#interestRate").value;
        var tenure = document.querySelector("#loanTenure").value;
        var elgloanamt = document.querySelector("#output > span:nth-child(2)").innerText.substring(2).replaceAll(",","");

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppCAPRI",
                     "ora.z_email": email,
                     "ora.z_loanAmtRequested": loanAmtRequested,
                     "ora.z_monthlyIncome": monthlyIncome,
                     "ora.z_monEMI": monEMI,
                     "ora.z_roi": roi,
                     "ora.z_tenure": tenure,
                     "ora.z_elgLoan": elgloanamt
                  }]
              };
        //console.log(payload);
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "caprihomeloans",
                "wt.ti": "caprihomeloans",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventCAPRI",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // your code
})();