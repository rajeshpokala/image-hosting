// ==UserScript==
// @name         fetchData
// @namespace    http://tampermonkey.net/
// @version      2025-06-26
// @description  try to take over the world!
// @author       You
// @match        https://freemarker.apache.org/docs/ref_builtins_string.html*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here... WP_rajeshdata
    window.recData = {
    "recommendations": [
        {
            "Product ID": "SKU1",
            "Name": "2024 Land Rover Range Rover Velar Dynamic HSE",
			"Material": "35,000 kms • Petrol • Automatic • 1st Owner",
			"Thumb Image URL": "https://images10.gaadi.com/usedcar_image/4603712/original/processed_e146718a99bca6e9cf46cb3acae41577.jpg?imwidth=640",
			"Image URL": "https://images10.gaadi.com/usedcar_image/4603712/original/processed_e146718a99bca6e9cf46cb3acae41577.jpg?imwidth=640",
			"Page URL": "https://www.cardekho.com/used-cars+in",
            "Price": "₹68 Lakh",
            "Formatted Price": null
        },
        {
            "Product ID": "SKU2",
            "Name": "P2021 Toyota Vellfire Executive Lounge BSVI",
			"Material": "35,000 kms • Petrol • Automatic • 1st Owner",
			"Thumb Image URL": "https://images10.gaadi.com/usedcar_image/4549326/original/processed_2ce44302371d1150b17189119943b4e9.jpg?imwidth=420",
            "Image URL": "https://images10.gaadi.com/usedcar_image/4549326/original/processed_2ce44302371d1150b17189119943b4e9.jpg?imwidth=420",
			"Page URL": "https://www.cardekho.com/used-cars+in",
            "Price": "₹88 Lakh",
            "Formatted Price": null
        },
        {
            "Product ID": "SKU3",
            "Name": "2022 Mercedes-Benz AMG GLC 43 4MATIC Coupe",
			"Material": "35,000 kms • Petrol • Automatic • 1st Owner",
			"Thumb Image URL": "https://images10.gaadi.com/usedcar_image/4617424/original/processed_86661b413cd452100d156223e0c0b914.jpg?imwidth=420",
            "Image URL": "https://images10.gaadi.com/usedcar_image/4617424/original/processed_86661b413cd452100d156223e0c0b914.jpg?imwidth=420",
			"Page URL": "https://www.cardekho.com/used-cars+in",
            "Price": "₹78 Lakh",
            "Formatted Price": null
        }
    ]
}
    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:test');
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "WP_rajeshdata",
                "ora.z_cid": "RAJESH_SFTP_1-1"
            }
        });
    };

    document.head.appendChild(script);

    // Your code end here...
})();