// ==UserScript==
// @name         poonawallafincorp
// @namespace    http://tampermonkey.net/
// @version      2024-09-26
// @description  try to take over the world!
// @author       You
// @match        https://poonawallafincorp.com/personal-loan/personal-loan-emi-calculator
// @icon         https://www.google.com/s2/favicons?sz=64&domain=poonawallafincorp.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //document.body.innerHTML = "Some new HTML content";
    //const element = document.getElementById("caculate-emi-btn");
    //element.addEventListener("click", captureFunction);
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="poonawallafincorp";
        var title = "poonawallafincorp";
        var eventid = Date.now();

        var email="kumar.rp1215@gmail.com";
        var loanAmtRequested = document.querySelector("#pocamt").value;
        var tag = "personal-loan-emi-calculator";
        var monEMI = document.querySelector("#portlet_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_b5sKEER1NvVM > div > div.portlet-content-container > div > div > div > div > div:nth-child(2) > div.journal-content-article > div > div > div:nth-child(1) > div > div.progress.mx-auto.myValue > div > div > span").innerText.replaceAll(",","").replaceAll("₹ ","");
        var roi = document.querySelector("#portlet_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_b5sKEER1NvVM > div > div.portlet-content-container > div > div > div > div > div:nth-child(2) > div.journal-content-article > div > div > div:nth-child(2) > div > div:nth-child(4) > input").value;
        var tenure = document.querySelector("#portlet_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_b5sKEER1NvVM > div > div.portlet-content-container > div > div > div > div > div:nth-child(2) > div.journal-content-article > div > div > div:nth-child(2) > div > div:nth-child(6) > input").value;

        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSuppPWFC",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_email": email,
                    "ora.z_loanAmtRequested": loanAmtRequested,
                    "ora.z_tag": tag,
                    "ora.z_monEMI": monEMI,
                    "ora.z_roi": roi,
                    "ora.z_tenure": tenure,
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "poonawallafincorp",
                "wt.ti": "poonawallafincorp",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventPWFC",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
})();