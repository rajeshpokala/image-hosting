// ==UserScript==
// @name         Taj Hotels Booking ABD
// @namespace    http://tampermonkey.net/
// @version      2025-04-28
// @description  try to take over the world!
// @author       You
// @match        https://www.tajhotels.com/en-in/bookings/landing-page?hotelId=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tajhotels.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        window.ondblclick = function() {showCountdown()};
    var email="kumar.rp1215@gmail.com";

    function showCountdown() {
        // Avoid creating multiple timers
        if (document.getElementById("countdown")) return;

        // Create the countdown div with inline styles
        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 15s";

        // Apply inline styles
        countdownDiv.style.fontSize = "24px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #ccc";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "50%";
        countdownDiv.style.right = "20px";
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 15;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.innerText = "Data Captured";
                //countdownDiv.remove(); // remove the div after countdown
                captureFunction();
            }
        }, 1000);
    }


        function captureFunction() {

        //alert("Data Captured ");
        //script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
			for (let i = 0; i < dataLayer.length; i++) {

				if (dataLayer[i].event == "view_cart"){
					//alert(dataLayer[i].arrivalDate);
					localStorage.arrivalDate = dataLayer[i].arrivalDate;
					localStorage.hotelname= dataLayer[i].ecommerce.items[0].item_brand;
					localStorage.price= dataLayer[i].ecommerce.items[0].price;
					localStorage.room_type= dataLayer[i].ecommerce.items[0].item_name;
				}
			}
        //};
            triggerNoEvent();
    }

    function triggerNoEvent() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerNoEvent",
                    "ora.z_arrivalDate": localStorage.arrivalDate,
                    "ora.z_hotelname": localStorage.hotelname,
                    "ora.z_roomprice": localStorage.price,
                    "ora.z_room_type": localStorage.room_type
                }
            });
        };

        document.head.appendChild(script);
    }

    // Your code ends here...
})();