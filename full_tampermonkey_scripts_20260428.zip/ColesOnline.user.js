// ==UserScript==
// @name         ColesOnline
// @namespace    http://tampermonkey.net/
// @version      2024-11-19
// @description  try to take over the world!
// @author       You
// @match        https://engage.oracle.com/515e50?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=oracle.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
     //alert("Data Captured ");
    var query = window.location.search.substring(1);
    var pair = query.split('=');

    myFunction();
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "wt.co_f": pair[1],
                    "user.eventname": "TriggerColesWPPage",
                    "user.email": pair[1]
                }
            });
        };
        document.head.appendChild(script);
         //window.ondblclick = function() {myFunction()};


    function myFunction() {
        //alert("Tab is closing");
        var cookies = document.cookie;

        var cookieArray = cookies.split(';');
        for (var i = 0; i < cookieArray.length; i++) {

            var cookiePair = cookieArray[i].split('=');
            //console.log(cookiePair[0]);
            if (cookiePair[0].trim() == "ORA_FPC") {
                console.log(cookiePair);
                //document.cookie = "ORA_FPC=id="+pair[1]+"; Expires=1970-12-24T12:03:38.474Z; path=/;";
                document.cookie = "ORA_FPC=id=; Expires=1970-12-24T12:03:38.474Z; path=/;";
                //cookieStore.delete(cookiePair[0]);
                //break;
           }

        }


    }
    // Your code ends...
})();