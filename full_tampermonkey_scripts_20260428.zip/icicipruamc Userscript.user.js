// ==UserScript==
// @name         icicipruamc Userscript
// @namespace    http://tampermonkey.net/
// @version      2026-01-12
// @description  try to take over the world!
// @author       You
// @match        https://www.icicipruamc.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=icicipruamc.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.addEventListener("load", () => {
        if(window.location.href.startsWith("https://www.icicipruamc.com/mutual-fund") == true){
            //alert("hello 1");
            window.ondblclick = function() { capturedetails(); };
        }

        if(window.location.href == "https://www.icicipruamc.com/home"){

            //alert("hello");
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "icicipruamcFunds"
                    }
                });
            }
            document.head.appendChild(script);
        }
    });


    function getText(selector) {
        const el = document.querySelector(selector);
        return el ? el.textContent.trim() : '';
    }

    function capturedetails() {
        let fundName = getText('.css-171h0ym');
        let schemePlan = document.querySelector('.MuiToggleButtonGroup-root button[aria-pressed="true"]')?.value;;
        let schemeOption = document.querySelector('#growth.MuiSelect-select')?.innerText.trim();
        let investmentType = document.querySelector('[aria-labelledby="invest-type"] + input.MuiSelect-nativeInput')?.value;
        let installmentAmount = document.querySelector('.MuiInputBase-root input[name="investAmount"]')?.value;
        let frequency = document.querySelector(".badge__list_selected .badge__text")?.innerText;
        let fromDate = document.querySelectorAll('.calender input.MuiInputBase-input')[0]?.value.trim();
        let toDate = document.querySelectorAll('.calender input.MuiInputBase-input')[1]?.value.trim();

        localStorage.setItem('icicifundName', fundName)
        localStorage.setItem('icicischemePlan', schemePlan)
        localStorage.setItem('icicischemeOption', schemeOption)
        localStorage.setItem('iciciinvestmentType', investmentType)
        localStorage.setItem('iciciinstallmentAmount', installmentAmount)
        localStorage.setItem('icicifrequency', frequency)
        localStorage.setItem('icicifromDate', fromDate)
        localStorage.setItem('icicitoDate', toDate)
        localStorage.setItem('curl', window.location.href);
        alert("hello 2");

    }

    // your code end here...
})();