// ==UserScript==
// @name         SMFG LOAN ELIGIBILITY
// @namespace    http://tampermonkey.net/
// @version      2024-02-22
// @description  try to take over the world!
// @author       You
// @match        https://www.smfgindiacredit.com/personal-loan-eligibility-calculator.aspx
// @icon         https://www.google.com/s2/favicons?sz=64&domain=smfgindiacredit.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var email="kumar.rp1215@gmail.com";
        var cookie="SMFG";
        var title = "SMFG";
        //var city = document.getElementsByClassName("select txtCity PL_select").city.value;
        var dob = document.querySelector("#PL-eligibilty-tab > div > div.formwrp > div > div > div.react-datepicker-wrapper > div > input").value;
        var netIncome = document.getElementsByClassName("rc-slider-handle")[0].ariaValueNow;
        var monEMI = document.getElementsByClassName("rc-slider-handle")[1].ariaValueNow;
        var roi = document.getElementsByClassName("rc-slider-handle")[2].ariaValueNow;
        var tenure = document.getElementsByClassName("rc-slider-handle")[3].ariaValueNow;
        var elgLoan = document.getElementsByClassName("eligibleAmt calc-amt")[0].innerText.replaceAll(",","").trim();

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppSMFG",
                     "ora.z_email": email,
                     "ora.z_city": "Mumbai",
                     "ora.z_dob": dob,
                     "ora.z_netIncome": netIncome,
                     "ora.z_monEMI": monEMI,
                     "ora.z_roi": roi,
                     "ora.z_tenure": tenure,
                     "ora.z_elgLoan": elgLoan
                  }]
              };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "SMFG",
                "wt.ti": "SMFG",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventSMFG",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

})();