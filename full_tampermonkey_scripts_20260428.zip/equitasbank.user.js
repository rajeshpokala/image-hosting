// ==UserScript==
// @name         equitasbank
// @namespace    http://tampermonkey.net/
// @version      2024-10-05
// @description  try to take over the world!
// @author       You
// @match        https://equitasbank.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=equitasbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        window.ondblclick = function() {
            if(location.href.endsWith("debit-cards/") == true)
            {
                alert("debit card page");
            }
            if(window.location.href == "https://equitasbank.com/")
            {
                alert(location.href);
            }
		};
   // Your code here...
})();