// ==UserScript==
// @name         Muthoot_Gold_Loan
// @namespace    http://tampermonkey.net/
// @version      2024-10-09
// @description  try to take over the world!
// @author       You
// @match        https://www.muthootfinance.com/gold-loan
// @icon         https://www.muthootfinance.com/sites/default/files/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    //document.body.innerHTML = "Some new HTML content";
    //const element = document.getElementById("generateOtp_btn2");
    localStorage.setItem('ltype', "Gold_Loan_Page");
    window.ondblclick = function() {captureFunction()};
    //element.addEventListener("ondblclick", captureFunction);

    function captureFunction() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="muthootfinance";
        var title = "muthootfinance";
        var eventid = Date.now();
        var cname = document.querySelector("#customer_name").value;
        var cemail = document.querySelector("#customer_email").value;
        var cphone = document.querySelector("#customer_phone").value;
        var cstate = document.querySelector("#customer_state").value;
        var cpincode = document.querySelector("#customer_pincode").value;
        var cgoldtype = document.querySelector("#selectgoldtpe").value;
        var cloanamt = document.querySelector("#loan_amount").value;
        var ccouponcode = generateCouponCode();
        alert("Data Captured");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "Triggergoldloan",
                    "ora.z_tag": "Gold_Loan",
                    "ora.z_cname": cname,
                    "ora.z_email": cemail,
                    "ora.z_mobilephone": cphone,
                    "ora.z_state": cstate,
                    "ora.z_pincode": cpincode,
                    "ora.z_loantype": cgoldtype,
                    "ora.z_expectedloanamount":cloanamt,
                    "ora.z_eventid": eventid,
                    "ora.z_qrcode": ccouponcode
                }
            });
        };
        document.head.appendChild(script);
        
        //setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "poonawallafincorp",
                "wt.ti": "poonawallafincorp",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventPWFC",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "veerubravo@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    function generateCouponCode() {
        //alert("in");
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let couponCode = '';
            for (let i = 0; i < 10; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                couponCode += characters.charAt(randomIndex);
            }

            return couponCode;
        }


})();