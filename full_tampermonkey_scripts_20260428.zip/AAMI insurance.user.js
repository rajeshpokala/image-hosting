// ==UserScript==
// @name         AAMI insurance
// @namespace    http://tampermonkey.net/
// @version      2024-12-12
// @description  try to take over the world!
// @author       You
// @match        https://engage.oracle.com/aami?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=oracle.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var query = window.location.search.substring(1);
    var pair = query.split('=');
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerProductCategory",
                    "ora.z_category":pair[1]
                }
            });
        };
        document.head.appendChild(script);
    // your code end here...
})();