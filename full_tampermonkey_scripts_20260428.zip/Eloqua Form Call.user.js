// ==UserScript==
// @name         Eloqua Form Call
// @namespace    http://tampermonkey.net/
// @version      2026-02-23
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://text-compare.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=text-compare.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // code to insert data into Eloqua CDO
    /*var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
    var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

    var payload = {
        "static": {
            "domain": "www.oracle.come"
        },
        "events": [{
            "ora.z_eventname": "TriggerEloquaForm",
            "ora.z_email": "kumar.rp1215+CDO3@gmail.com",
            "ora.z_billamt": "Bill Amount 5"
        }]
    };

    xmlhttp.open("POST", url);
    xmlhttp.setRequestHeader("Content-Type", "application/json");
    xmlhttp.send(JSON.stringify(payload));*/

    // code to send email using C360 data
    var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
    var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

    var payload = {
        "static": {
            "domain": "www.oracle.come"
        },
        "events": [{
            "ora.z_eventname": "WP_2Responsysdata",
            "ora.z_email": "kumar.rp1215@gmail.com",
            "ora.z_cid": "RAJESH_SFTP_1-1"
        }]
    };

    xmlhttp.open("POST", url);
    xmlhttp.setRequestHeader("Content-Type", "application/json");
    xmlhttp.send(JSON.stringify(payload));


    // your code ends...
})();