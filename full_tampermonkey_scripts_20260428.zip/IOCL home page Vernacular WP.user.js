// ==UserScript==
// @name         IOCL home page Vernacular WP
// @namespace    http://tampermonkey.net/
// @version      2025-05-21
// @description  try to take over the world!
// @author       You
// @match        https://cx.indianoil.in/webcenter/portal/Customer/pages*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=indianoil.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    localStorage.ltxt = "एलपीजी, पेट्रोल पंप, ल्यूब्स आदि पर सामान्य शिकायत / फीडबैक के लिए";
    if(location.href.indexOf("p5kgftl")>0){
        localStorage.chhotu = "Y";
    }
    var chhotu = localStorage.getItem("chhotu") ;
    triggerWP();
    if(chhotu == "Y"){
        triggerWP1();
    }

    function triggerWP() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerHomePageIOCL",
                    "ora.z_tag": "Home Page vernacular"
                }
            });
        };

        document.head.appendChild(script);
    }
    function triggerWP1() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerchhotuIOCL",
                    "ora.z_tag": "Home Page vernacular"
                }
            });
        };

        document.head.appendChild(script);
    }
    // Your code here...
})();