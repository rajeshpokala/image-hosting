// ==UserScript==
// @name         ACT PageVisit Tracking
// @namespace    http://tampermonkey.net/
// @version      2025-10-22
// @description  try to take over the world!
// @author       You
// @match        https://www.actcorp.in/*
// @icon         https://www.actcorp.in/sites/default/files/favicon_1.png
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "ACT_PagevisitTracking"
                }
            });
        }
    document.head.appendChild(script);
})();