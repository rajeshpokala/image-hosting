// ==UserScript==
// @name         AAVAS loan calc
// @namespace    http://tampermonkey.net/
// @version      2025-01-13
// @description  try to take over the world!
// @author       You
// @match        https://www.aavas.in/home-loan-emi-calculator
// @icon         https://www.google.com/s2/favicons?sz=64&domain=aavas.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

    window.ondblclick = function() {captureFunction()};
     function captureFunction() {
	 alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        //var custid = document.querySelector("#edit-call-custid").value;
		var email = "ramandinkar@gmail.com";
        var name = "Rajesh Pokala";
        var mobilenumber = "00919899768587";
        var interestedproduct = "Home Loan";
        //var comments = document.querySelector("#edit-callback-message").value;

        var cookie="AAVAS FINANCIERS LIMITED";
        var title = "AAVAS FINANCIERS LIMITED";
        var eventid = Date.now();

        var loanAmtRequested = document.querySelector("#rangevalue").value;
        var tag = "Home_Loan"
        var monEMI = document.querySelector("#emi").innerText.replaceAll(",","");
        var roi = document.querySelector("#rangevalue1").value;
        var tenure = document.querySelector("#rangevalue2").value;

		//localStorage.custid = custid;
		localStorage.email = email;
		localStorage.loanAmtRequested = loanAmtRequested;
		localStorage.monEMI = monEMI;
		localStorage.roi = roi;
		localStorage.tenure = tenure;
	 	localStorage.firstname = name;

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppAAVAS",
                     "ora.z_email": email,
                     "ora.z_firstname": name,
                     "ora.z_phone": mobilenumber,
                     "ora.z_interestarea": interestedproduct,
                     "ora.z_loanAmtRequested": loanAmtRequested,
                     "ora.z_tag": tag,
                     "ora.z_monEMI": monEMI,
                     "ora.z_roi": roi,
                     "ora.z_tenure": tenure,
                     "ora.z_eventid": eventid
                  }]
              };
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
 }
    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var emailid="ramandinkar@gmail.com";
        var payload = {
                "static": {
                "wt.co_f": "AAVAS FINANCIERS LIMITED",
                "wt.ti": "AAVAS FINANCIERS LIMITED",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventAAVAS",
                     "ora.z_tag_id": "1",
                     "ora.z_email": emailid
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // Your code here...
})();