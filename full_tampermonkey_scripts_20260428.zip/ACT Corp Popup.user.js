// ==UserScript==
// @name         ACT Corp Popup
// @namespace    http://tampermonkey.net/
// @version      2026-01-07
// @description  try to take over the world!
// @author       You
// @match        https://selfcare.actcorp.in/home
// @icon         https://www.google.com/s2/favicons?sz=64&domain=actcorp.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // Show only once per session
    if (sessionStorage.getItem('ci_popup_shown')) return;
    sessionStorage.setItem('ci_popup_shown', 'true');

    // Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'ci-backdrop';
    backdrop.style.cssText = `
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.45);
    display:flex;
    align-items:center;
    justify-content:center;
    z-index:9999;
  `;

    // Modal
    const modal = document.createElement('div');
    modal.style.cssText = `
    width:90%;
    max-width:420px;
    background:#ffffff;
    border-radius:8px;
    box-shadow:0 12px 40px rgba(0,0,0,0.2);
    padding:24px 22px 26px;
    font-family:Arial,Helvetica,sans-serif;
    position:relative;
  `;

    modal.innerHTML = `
    <button id="ci-close" style="
      position:absolute;
      top:14px;
      right:14px;
      background:none;
      border:none;
      font-size:18px;
      cursor:pointer;
      color:#333;
    ">✕</button>

    <h2 style="
      margin:0 0 18px;
      font-size:22px;
      font-weight:600;
      color:#11699e;
    ">Log In</h2>

    <label style="font-size:14px;color:#a7a9ac;">Mobile Number</label>
    <input id="ci-mobile" type="tel" maxlength="10"
      placeholder="Enter Your ID"
      style="
        width:100%;
        height:44px;
        padding:10px 12px;
        margin:6px 0 14px;
        border:1px solid #d6d6d6;
        border-radius:4px;
        font-size:14px;
        box-sizing:border-box;
        outline:none;
      " />

    <label style="font-size:14px;color:#a7a9ac;">Select City</label>
    <select id="ci-type"
      style="
        width:100%;
        height:44px;
        padding:10px 12px;
        margin:6px 0 20px;
        border:1px solid #d6d6d6;
        border-radius:4px;
        font-size:14px;
        box-sizing:border-box;
        background:#fff;
        outline:none;
      ">
      <option value="">Select</option>
      <option value="bengaluru">Bengaluru </option>
      <option value="chennai">Chennai</option>
    </select>

    <button id="ci-submit" style="
      width:100%;
      height:46px;
      background:#eb2222;
      border:none;
      border-radius:4px;
      color:#fff;
      font-size:15px;
      font-weight:600;
      cursor:pointer;
    ">Submit</button>
  `;

    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    // Close handlers
    document.getElementById('ci-close').onclick = () => backdrop.remove();
    backdrop.onclick = e => { if (e.target === backdrop) backdrop.remove(); };

    // Input focus styling
    ['ci-mobile', 'ci-type'].forEach(id => {
        const el = document.getElementById(id);
        el.onfocus = () => el.style.borderColor = '#1e88e5';
        el.onblur = () => el.style.borderColor = '#d6d6d6';
    });

    // Submit handler
    document.getElementById('ci-submit').onclick = () => {
        const mobile = document.getElementById('ci-mobile').value.trim();
        const type = document.getElementById('ci-type').value;


        if (!type) {
            alert('Please select City');
            return;
        } else{
            fetch('https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true', {
                method: 'POST',
                body: JSON.stringify({
                    "static": {
                        "wt.dcsvid": mobile,
                        "user.phone": mobile,
                        "user.category": type
                    },
                    "events": [{
                        "dcsuri": location.href,
                        "wt.dl": "0",
                        "wt.ets": parseInt(+new Date() / 1000, 10)
                    }]
                })
            })
                .then(response => response.json())
                .then(body => console.log(body));
        }

        console.log('CareInsurance Popup Data:', { mobile, type });

        backdrop.remove();
    };
    // Your code here...
})();