// ==UserScript==
// @name         cardekho Used cars
// @namespace    http://tampermonkey.net/
// @version      2025-06-17
// @description  try to take over the world!
// @author       You
// @match        https://www.cardekho.com/*used-car-details/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=cardekho.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
     window.ondblclick = function() {capturedetails();captureFunction();};
    function capturedetails() {
        alert("data captured");
        localStorage.pimg = document.querySelector("div.slick-slide.slick-active.slick-current > div > img").src;
        localStorage.pname = document.querySelector("div.vehicleName").innerText;
        localStorage.pprice = document.querySelector("div.vehiclePrice > span").innerText;
        localStorage.vehicleDotList = document.querySelector("div.vehicleDotList").innerText;
        localStorage.pageLocurl = window.location.href;

        const containers = document.querySelectorAll(".recomended-used-cars-container");

        containers.forEach(container => {
            const slides = container.querySelectorAll('[data-index="0"], [data-index="1"]');
            localStorage.pimg0 = slides[0].querySelector("img")?.src;
            localStorage.pname0 = slides[0].querySelector("h3.title a")?.innerText.trim();
            localStorage.pprice0 = slides[0].querySelector(".Price p")?.innerText.trim();

            localStorage.pimg1 = slides[1].querySelector("img")?.src;
            localStorage.pname1 = slides[1].querySelector("h3.title a")?.innerText.trim();
            localStorage.pprice1 = slides[1].querySelector(".Price p")?.innerText.trim();
        });


        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var chkdat = localStorage.pimg;

        script.onload = () => {
            // Code to execute after the script has loaded
            if(chkdat != null){
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerHomePageCAR",
                        "ora.z_email": "kumar.rp1215@gmail.com",
                        "ora.z_tag": "Home Page",
                        "ora.z_pimg": localStorage.pimg,
                        "ora.z_pimg0": localStorage.pimg0,
                        "ora.z_pimg1": localStorage.pimg1,
                        "ora.z_pname": localStorage.pname,
                        "ora.z_pname0": localStorage.pname0,
                        "ora.z_pname1": localStorage.pname1,
                        "ora.z_pprice": localStorage.pprice,
                        "ora.z_pprice0": localStorage.pprice0,
                        "ora.z_pprice1": localStorage.pprice1,
                        "ora.z_recommendStr": localStorage.recommendStr,
                        "ora.z_vehicleDotList": localStorage.vehicleDotList,
                        "ora.z_pageloc": localStorage.pageLocurl
                    }
                });
            }
        };
        document.head.appendChild(script);

    }
        function captureFunction() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var eventid = Date.now();
        var email="veerubravo@gmail.com";
        var phone="00919842282592";
        var tag = "CarDekho Page view";
        var location = document.querySelector("#vdp-main > div > div > div:nth-child(1) > div.gsc_col-xs-12.gsc_col-md-5.gsc_col-lg-4.stickyPos > div.vehicle-description.lowPadding > div > div.flexitem > div.distanceText").innerText;
        var vehiclename = document.querySelector("#vdp-main > div > div > div:nth-child(1) > div.gsc_col-xs-12.gsc_col-md-5.gsc_col-lg-4.stickyPos > div.vehicle-description > div > div.vehicleName").innerText;
        var vehiclePrice = document.querySelector("#vdp-main > div > div > div:nth-child(1) > div.gsc_col-xs-12.gsc_col-md-5.gsc_col-lg-4.stickyPos > div.vehicle-description > div > div.vehiclePrice").innerText.replaceAll("Make Your Offer","");
        var emi = document.querySelector("#emi-widget-cta").innerText;
        var NcPrice = document.querySelector("#vdp-main > div > div > div:nth-child(1) > div.gsc_col-xs-12.gsc_col-md-5.gsc_col-lg-4.stickyPos > div.vehicle-description > div > div.flexbox > div.NcPrice").innerText;
        var Regyear = document.querySelector("#vdpCard-carOverview > ul > li:nth-child(1) > div > div > span").innerText;
        var FuelType = document.querySelector("#vdpCard-carOverview > ul > li:nth-child(3) > div > div > span").innerText;
        var KmsDriven = document.querySelector("#vdpCard-carOverview > ul > li:nth-child(5) > div > div > span").innerText;
        var Ownership = document.querySelector("#vdpCard-carOverview > ul > li:nth-child(7) > div > div > span").innerText;
        var Transmission = document.querySelector("#vdpCard-carOverview > ul > li:nth-child(9) > div > div > span").innerText;
        var Yearofmanu = document.querySelector("#vdpCard-carOverview > ul > li:nth-child(10) > div > div > span").innerText

        //alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventid": eventid,
                    "ora.z_eventname": "TriggerCarDekhoSupp",
                    "ora.z_email": email,
                    "ora.z_phone": phone,
                    "ora.z_location": location,
                    "ora.z_vehiclename": vehiclename,
                    "ora.z_vehiclePrice": vehiclePrice,
                    "ora.z_emi": emi,
                    "ora.z_NcPrice": NcPrice,
                    "ora.z_Regyear": Regyear,
                    "ora.z_FuelType": FuelType,
                    "ora.z_KmsDriven": KmsDriven,
                    "ora.z_Ownership": Ownership,
                    "ora.z_Transmission": Transmission,
                    "ora.z_Yearofmanu": Yearofmanu
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "CarDekho",
                "wt.ti": "CarDekho",
               },
               "events": [{
                     "ora.z_eventname": "TriggerCarDekhoCE",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "veerubravo@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

    // Your code here...
})();