// ==UserScript==
// @name         Care Insurance Home Page
// @namespace    http://tampermonkey.net/
// @version      2025-04-07
// @description  try to take over the world!
// @author       You
// @match        https://www.careinsurance.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=careinsurance.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        var insutype = localStorage.desti;
    if(insutype != null){
        triggerWP();
    }
    triggerWP();
    function triggerWP() {
        //alert("good");
        var insutype = localStorage.desti;

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
console.log(insutype);
        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            //alert("hello");
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "WP_carehomepage",
                    "ora.z_ccardtype": insutype
                }
            });
        };
        document.head.appendChild(script);
        sessionStorage.clear();
    }
    // Your code End here...
})();