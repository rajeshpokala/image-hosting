// ==UserScript==
// @name         Kotak Life
// @namespace    http://tampermonkey.net/
// @version      2024-09-05
// @description  try to take over the world!
// @author       You
// @match        https://www.kotaklife.com/life-insurance-plans/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=kotaklife.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};
  function captureFunction() {
        alert("Sending abandoned event");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings

        var cookie="kotaklife";
        var title = "kotaklife";

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerCEKotak",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
    };
 // Your code here...
})();