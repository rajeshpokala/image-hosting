// ==UserScript==
// @name         karnatakabank
// @namespace    http://tampermonkey.net/
// @version      2024-07-30
// @description  try to take over the world!
// @author       You
// @match        https://karnatakabank.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=karnatakabank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    // Your code here...
    window.addEventListener('beforeunload', function(e) {
        localStorage.setItem('lsloanAmtRequested', document.querySelector("div.slider-show-value.heading24.semibold > input").value.replaceAll(",",""));
        localStorage.setItem('lsroi', document.querySelector("div.slider-show-value.heading24.semibold.rates-deci > input").value);
        localStorage.setItem('lstenure', document.querySelector("div.slider-show-value.heading24.semibold.months > input").value);
        localStorage.setItem('lsemi', document.querySelector(".pay-content").innerText.substring(15,document.querySelector(".pay-content").innerText.lastIndexOf("/")));
        localStorage.setItem('lstag', window.location.href.substring(window.location.href.lastIndexOf("/")+1));
        console.log("moving to next page");
        //return false;
    });

    window.ondblclick = function() {if(window.location.href.substring(window.location.href.lastIndexOf("/")+1) == "apply-now"){captureFunction()}};

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var email=document.querySelector("#edit-callback-email").value;
        var name = document.querySelector("#edit-call-name").value;
        var mobilenumber = document.querySelector("#edit-callback-mobile-number").value;
        var interestedproduct = document.querySelector("#select2-edit-interested-product-service-container").innerText;
        var comments = document.querySelector("#edit-callback-message").value;

        var cookie="karnatakabank";
        var title = "karnatakabank";
        var eventid = Date.now();

        var loanAmtRequested = localStorage.lsloanAmtRequested;
        var tag = localStorage.lstag;
        var monEMI = localStorage.lsemi.replaceAll(",","");
        var roi = localStorage.lsroi;
        var tenure = localStorage.lstenure;

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppKB",
                     "ora.z_email": email,
                     "ora.z_firstname": name,
                     "ora.z_phone": mobilenumber,
                     "ora.z_interestarea": interestedproduct,
                     "ora.z_message": comments,
                     "ora.z_loanAmtRequested": loanAmtRequested,
                     "ora.z_tag": tag,
                     "ora.z_monEMI": monEMI,
                     "ora.z_roi": roi,
                     "ora.z_tenure": tenure,
                     "ora.z_eventid": eventid
                  }]
              };
        //console.log(payload);
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var emailid=document.querySelector("#edit-callback-email").value;
        var payload = {
                "static": {
                "wt.co_f": "karnatakabank",
                "wt.ti": "karnatakabank",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventKB",
                     "ora.z_tag_id": "1",
                     "ora.z_email": emailid
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // your code
})();