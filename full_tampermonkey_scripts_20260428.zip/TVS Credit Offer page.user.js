// ==UserScript==
// @name         TVS Credit Offer page
// @namespace    http://tampermonkey.net/
// @version      2026-03-20
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.tvscredit.com/special-offers/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tvscredit.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var cseg = localStorage.getItem("segmentName");
    if(cseg != null){ //alert(cseg);
        callWP(cseg);
    }
    const STORAGE_KEY = 'edgeverve_segment_choice';

    if (document.getElementById('ev-segment-toggle')) return;

    // styles
    const css = `
    #ev-segment-toggle {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 2147483647;
      background: linear-gradient(180deg, #ffffff, #f7fbff);
      border: 1px solid rgba(11,95,165,0.12);
      box-shadow: 0 6px 18px rgba(11,95,165,0.14);
      border-radius: 10px;
      padding: 10px 12px;
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      color: #07243a;
      min-width: 160px;
    }
    #ev-segment-toggle h4 {
      margin: 0 0 8px 0;
      font-size: 15px;
      font-weight: 700;
      letter-spacing: -0.2px;
    }
    #ev-segment-toggle .ev-options {
      display:flex;
      gap:8px;
      align-items:center;
      justify-content:space-between;
    }
    #ev-segment-toggle label {
      display:inline-flex;
      align-items:center;
      gap:6px;
      cursor:pointer;
      font-size:13px;
      color:#08324a;
    }
    #ev-segment-toggle input[type="radio"] {
      width:14px;
      height:14px;
    }
    #ev-segment-toggle .ev-help {
      margin-top:8px;
      font-size:11px;
      color:#4a6b87;
    }
    #ev-segment-toggle .ev-close {
      position:absolute;
      top:4px;
      right:4px;
      background:transparent;
      border:none;
      color:#4a6b87;
      cursor:pointer;
      font-size:14px;
    }
    @media (max-width:480px){
      #ev-segment-toggle { right:10px; bottom:10px; min-width:140px; padding:8px; }
      #ev-segment-toggle h4 { font-size:12px; }
    }
  `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);

    // build panel
    const panel = document.createElement('div');
    panel.id = 'ev-segment-toggle';
    panel.setAttribute('role', 'region');
    panel.setAttribute('aria-label', 'Segment toggle');
    panel.innerHTML = `
    <button class="ev-close" aria-label="Close toggle">✕</button>
    <h4>Choose segment</h4>
    <div class="ev-options" role="radiogroup" aria-label="Segment options">
      <label title="Financial">
        <input type="radio" name="evSegment" value="tamil nadu" />
        <span>Tamil Nadu</span>
      </label>
      <label title="Telecom">
        <input type="radio" name="evSegment" value="karnataka" />
        <span>Karnataka</span>
      </label>
    </div>
    <div class="ev-help">Change will refresh the page</div>
  `;
    document.body.appendChild(panel);

    const radioFinancial = panel.querySelector('input[value="tamil nadu"]');
    const radioTelecom = panel.querySelector('input[value="karnataka"]');
    const closeBtn = panel.querySelector('.ev-close');

    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'tamil nadu') radioFinancial.checked = true;
    else if (saved === 'karnataka') radioTelecom.checked = true;

    function onChange(e) {
        try {
            const val = e.target.value;
            // store choice
            localStorage.setItem(STORAGE_KEY, val);
            radioFinancial.disabled = true;
            radioTelecom.disabled = true;
            //alert(val);
            localStorage.setItem("segmentName", val);
            callWP(val);
            setTimeout(function() {location.reload()},1000);

        } catch (err) {
            console.error('Segment toggle error', err);
        }
    }

    radioFinancial.addEventListener('change', onChange);
    radioTelecom.addEventListener('change', onChange);

    closeBtn.addEventListener('click', () => {
        panel.style.display = 'none';
    });

    window.addEventListener('keydown', (ev) => {
        if (ev.ctrlKey && (ev.key === 'm' || ev.key === 'M')) {
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        }
    });

    function callWP(cseg){
        //alert(cseg);
        function delete_cookie( name, path, domain ) {
            document.cookie = name + "=" +
                ((path) ? ";path="+path:"")+
                ((domain)?";domain="+domain:"") +
                ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
        }

        delete_cookie("ORA_FPC", "/", ".tvscredit.com");
        delete_cookie("FPC", "/", ".tvscredit.com");
        localStorage.removeItem("ORA_COOK_STORE");

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var eventid = Date.now();
        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully: Offers Page');
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerofferpagetvsC",
                    "ora.z_tag": cseg
                }
            });
        };
        document.head.appendChild(script);
        //sessionStorage.clear(); "wt.dl": 0,
    }
    // Your code here...
})();