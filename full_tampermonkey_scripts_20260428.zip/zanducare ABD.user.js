// ==UserScript==
// @name         zanducare ABD
// @namespace    http://tampermonkey.net/
// @version      2024-11-07
// @description  try to take over the world!
// @author       You
// @match        https://zanducare.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=zanducare.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //alert("collections");
    if(window.location.href.startsWith("https://zanducare.com/collections/"))
    {
        //alert("collections");
        localStorage.setItem('prdCate', window.location.href.replaceAll("https://zanducare.com/collections/",""));
    }

        window.ondblclick = function() {
            if(window.location.href.startsWith("https://zanducare.com/cart"))
            {
                captureFunction()
            }
            else if(window.location.href.startsWith("https://zanducare.com/products/"))
            {
                const imgTag = document.getElementsByTagName('img');
                console.log("Clicked element classname:", imgTag[1].src);
                var prdImg = imgTag[1].src;
                localStorage.setItem('prdImg', prdImg);
            }

        };

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        localStorage.setItem('prdPrice', document.querySelector("#shopify-section-template--15578546438219__main > section > div.cart-wrapper > div > div > div > form > div > div.card > div > div.cart-recap__price-line.text--pull > span.cart-recap__price-line-price").textContent.substr(1));
        localStorage.setItem('prdTotal', document.querySelector("#shopify-section-template--15578546438219__main > section > div.cart-wrapper > div > div > div > div > div > table > tbody > tr > td.line-item__quantity.table__cell--center.hidden-phone > div > input").value);
        localStorage.setItem('prdName', document.querySelector("#shopify-section-template--15578546438219__main > section > div.cart-wrapper > div > div > div > div > div > table > tbody > tr > td.line-item__product-info > div > div.line-item__meta > a").innerText);
        var eventid = Date.now();
        //alert(localStorage.prdName);
        var payload = {
                "static": {
                "wt.co_f": "zanducare",
                "wt.ti": "zanducare",
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppZandu",
                     "ora.z_email": "kumar.rp1215@gmail.com",
                     "ora.z_pName": localStorage.prdName,
                     "ora.z_pimg": localStorage.prdImg,
                     "ora.z_pPrice": localStorage.prdPrice,
                     "ora.z_pTotal": localStorage.prdTotal,
                     "ora.z_pCate": localStorage.prdCate,
                     "ora.z_visited": "zanducare.com",
                     "ora.z_eventid": eventid
                  }]
              };
        //console.log(payload);
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));

        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var emailid = "kumar.rp1215@gmail.com";
        var payload = {
                "static": {
                "wt.co_f": "zanducare",
                "wt.ti": "zanducare",
               },
               "events": [{
                     "ora.z_eventname": "TriggerCEzandu",
                     "ora.z_tag_id": "1",
                     "ora.z_email": emailid
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }



     // Your code here...
})();