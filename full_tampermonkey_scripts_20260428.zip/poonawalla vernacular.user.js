// ==UserScript==
// @name         poonawalla vernacular
// @namespace    http://tampermonkey.net/
// @version      2024-10-07
// @description  try to take over the world!
// @author       You
// @match        https://poonawallafincorp.com/personal-loan
// @icon         https://www.google.com/s2/favicons?sz=64&domain=poonawallafincorp.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerVernacularCalcPage",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_tag": "calc Page",
                    "ora.z_lang": "Hindi"
                }
            });
        };
        document.head.appendChild(script);

    //window.onbeforeunload = function(event) {
     window.ondblclick = function() {myFunction()};


    function myFunction() {
        alert("Tab is closing");
        var cookies = document.cookie;

        var cookieArray = cookies.split(';');
        for (var i = 0; i < cookieArray.length; i++) {

            var cookiePair = cookieArray[i].split('=');
            //console.log(cookiePair[0]);
            if (cookiePair[0].trim() == "ORA_FPC") {
                console.log(cookiePair[0]);
                document.cookie = "ORA_FPC=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                //cookieStore.delete(cookiePair[0]);
                //break;
           } else if (cookiePair[0].trim() == "ORA_PERS") {
               console.log(cookiePair[0]);
               document.cookie = "ORA_PERS=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
           }


        }


    }
    // Your code here...
})();