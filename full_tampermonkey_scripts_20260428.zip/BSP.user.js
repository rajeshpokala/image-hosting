// ==UserScript==
// @name         BSP
// @namespace    http://tampermonkey.net/
// @version      2025-02-21
// @description  try to take over the world!
// @author       You
// @match        https://www.bsp.com.pg/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=com.pg
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
   // window.ondblclick = function() {captureFunction()};
    window.ondblclick = function() {triggercomm()};
    function triggercomm(){
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/c5rdvb5d5f/js/anz_se_demo_tag/odc.js";
        script.async = true;
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerCOMMBSP",
                    "ora.z_email": "YOUR EMAIL",
                    "ora.z_phone": "MOBILE NUMBER",
                }
            });
        };
        document.head.appendChild(script);

    }

    captureFunction()
    function captureFunction() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/c5rdvb5d5f/js/anz_se_demo_tag/odc.js";
        script.async = true;
        var cookie="BSP";
        var title = "BSP";
        var eventid = Date.now();
        var email="shuo.w.wang@oracle.com";
        var phone="00919842282592";
        var tag = "BSP personal loan";
        //var loanAmtRequested = document.querySelector("#loan-amt-personal-input").value.replaceAll(",","");
        //var monEMI = document.querySelector("#emi_amt_personal").innerText.replaceAll("₹ ","").replaceAll(",","");
        //var roi = document.querySelector("#interest-rate-personal-input").value;
        //var tenure = document.querySelector("#tenure-months-personal-input").value;
        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSuppBSP",
                    "ora.z_email": email,
                    "ora.z_phone": phone,
                    "ora.z_tag": tag,
                    "ora.z_eventid": eventid,
                    "ora.z_interestarea": "BSP Personal Loan"
                }
            });
        };
        document.head.appendChild(script);
    }
})();