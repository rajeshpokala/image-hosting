// ==UserScript==
// @name         Test a Tag
// @namespace    http://tampermonkey.net/
// @version      2024-11-14
// @description  try to take over the world!
// @author       You
// @match        https://www.avira.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=avira.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        const anchorTag = document.getElementsByTagName('a');
        alert("hello");
        var arr = Array.from(Array(anchorTag.length), () => new Array(1));
        for (let i = 0; i < anchorTag.length; i++) {
            //arr[i][0] = anchorTag[i].innerText;
            if(arr[i][1].includes(anchorTag[i].href)){
                alert("duplicate");
            }
            arr[i][1] = anchorTag[i].href;
            //console.log(anchorTag[0].href);
        }
    console.log(arr);
    // Your code here...
})();