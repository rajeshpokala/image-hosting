// ==UserScript==
// @name         zurichkotak
// @namespace    http://tampermonkey.net/
// @version      2025-09-27
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.zurichkotak.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=zurichkotak.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.addEventListener("load", () => {
        if(window.location.href.startsWith("https://www.zurichkotak.com/travel-insurance") == true){

            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;
            script.onload = () => {
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerWPzKotak"
                    }
                });
            };
            document.head.appendChild(script);
            sessionStorage.clear();

            window.ondblclick = function() { capturedetails();};
        }
        if(window.location.href == "https://www.zurichkotak.com/"){
            //alert("here");
            triggerwp();
        }
        if(window.location.href.startsWith("https://www.zurichkotak.com/?em=") == true){

            triggerwp();
        }
    });
    function capturedetails() {
        //alert("here0");
        const dateInputs = document.querySelectorAll('input.txt-input.date[placeholder="DD/MM/YYYY"]');

        localStorage.travelCountry = document.querySelector('.MuiTypography-root.MuiTypography-body1.css-fyswvn').textContent;
        localStorage.adultcnt = document.querySelectorAll('.txt-grp')[1].querySelector('.counter-value').innerHTML;
        localStorage.childcnt = document.querySelectorAll('.txt-grp')[2].querySelector('.counter-value').innerHTML;
        localStorage.ldate = document.querySelectorAll('button[placeholder="DD/MM/YYYY"]')[0].value;
        localStorage.rdate = document.querySelectorAll('button[placeholder="DD/MM/YYYY"]')[1].value;
        localStorage.mobileno = document.querySelector('#mobileNo').value;
        localStorage.pageLocurl = window.location.href;

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var chkdat = localStorage.travelCountry;
        var chkeml = localStorage.email_addr;
        var eventid = Date.now();

        script.onload = () => {
            // Code to execute after the script has loaded
            if(chkdat != null){
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerzKotakproductPage",
                        "ora.z_tag": "Home Page",
                        "ora.z_email": chkeml,
                        "wt.dcsvid": chkeml,
                        "user.travelCountry": localStorage.travelCountry,
                        "user.adultcnt": localStorage.adultcnt,
                        "user.childcnt": localStorage.childcnt,
                        "user.ldate": localStorage.ldate,
                        "user.rdate": localStorage.rdate,
                        "user.mobileno": localStorage.mobileno,
                        "ora.z_eventid": eventid,
                        "ora.z_custid": "1_139598"
                    }
                });
            }
        };
        document.head.appendChild(script);

    }

    function triggerwp() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var chkdat = localStorage.travelCountry;
        var chkeml = localStorage.email_addr;
        var em = getQueryVariable('em');

        if (em == null){em = localStorage.email_addr;}

        script.onload = () => {
            // Code to execute after the script has loaded
            //alert("here1");
            if(chkdat != null){
                console.log('Script loaded successfully: 1');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerzkotakHomePage",
                        "wt.dcsvid": em,
                        "ora.z_tag": "Home Page"
                    }
                });
            } else if(em != null){
                console.log('Script loaded successfully: 2');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerzkotakHomePage",
                        "wt.dcsvid": em,
                        "ora.z_tag": "Home Page"
                    }
                });
            }
        };
        document.head.appendChild(script);
    }

    function getQueryVariable(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split('&');
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (decodeURIComponent(pair[0]) == variable) {
                return decodeURIComponent(pair[1]);
            }
        }
        console.log('Query variable %s not found', variable);
    }

    function showCountdown() {
        if (document.getElementById("countdown")) return;

        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 10s";

        countdownDiv.style.fontSize = "20px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #ccc";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "30%";
        countdownDiv.style.right = "20px";
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 10;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.innerText = "Data Captured";
                //countdownDiv.remove(); // remove the div after countdown
                capturedetails();
            }
        }, 1000);
    }
    // Your code here...
})();