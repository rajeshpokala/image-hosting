// ==UserScript==
// @name         Tata1mg WP Anonymous
// @namespace    http://tampermonkey.net/
// @version      2025-03-08
// @description  try to take over the world!
// @author       You
// @match        https://www.1mg.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=1mg.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var pimg = localStorage.pimg;
    var pname = localStorage.pname;
    var pprice = localStorage.pprice;
    var purl = localStorage.purl;
    if(pimg != null){
        triggerWP();
    }else{
        triggertitle();
    }

    function triggertitle(){
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "Tata1mg",
                "wt.ti": "Tata1mg",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventdummy",
                     "ora.z_tag_id": "1",
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

    function triggerWP() {
    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        //alert("hello");
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "TriggerWP1mgANS",
                "ora.z_email": "kumar.rp1215@gmail.com",
                "ora.z_pname": pname,
                "ora.z_pprice": pprice,
                "ora.z_pimg": pimg,
                "ora.z_purl": purl
            }
        });
    };
document.head.appendChild(script);
sessionStorage.clear();
    }
    // Your code here...
})();