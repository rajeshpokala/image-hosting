// ==UserScript==
// @name         idfcfirstbank
// @namespace    http://tampermonkey.net/
// @version      2025-07-28
// @description  try to take over the world!
// @author       You
// @match        https://www.idfcfirstbank.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=idfcfirstbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};
    if(window.location.href == "https://www.idfcfirstbank.com/"){
        //alert("here");
        var insutype = localStorage.cvist;
        if(insutype != null){
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                console.log('Script loaded successfully:');
                //alert("hello");
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "WP_idfchomepage"
                    }
                });
            };
            document.head.appendChild(script);

        }
    }
    if(window.location.href == "https://www.idfcfirstbank.com/credit-card"){
        //alert("here");
        var insutype0 = localStorage.cvist;
        if(insutype0 != null){
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                console.log('Script loaded successfully:');
                //alert("hello");
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "WP_idfcCCpage"
                    }
                });
            };
            document.head.appendChild(script);
        }
    }

    if(window.location.href == "https://www.idfcfirstbank.com/credit-card/metal-credit-card/ashva"){
        //alert("here");
        localStorage.cvist = "yes";
    }


    function captureFunction() {
        if(window.location.href.includes("personal-loan")){
            var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
            var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
            var email= "kumar.rp1215@gmail.com";
            var eventid = Date.now();
            const monEMI = document.querySelector("#plResult").textContent.replaceAll("/Month","").replaceAll(",","").replaceAll("₹","");

            var payload = {
                "static": {
                    "wt.co_f": "idfcfirstbank",
                    "wt.ti": "idfcfirstbank",
                },
                "events": [{
                    "ora.z_eventname": "TriggerEventIDFCBank",
                    "ora.z_email": email,
                    "ora.z_loanAmtRequested": document.querySelector("#gfm-amt").value,
                    "ora.z_monEMI": monEMI,
                    "ora.z_roi": document.querySelector("#gfm-intrest").value,
                    "ora.z_tenure": document.querySelector("#gfm-period").value,
                    "ora.z_eventid": eventid,
                    "ora.z_interestarea": "Personal Loan"
                }]
            };

            xmlhttp1.open("POST", url1);
            xmlhttp1.setRequestHeader("Content-Type", "application/json");
            xmlhttp1.send(JSON.stringify(payload));
            alert("Data Captured ");
        }
    }
    // Your code here...
})();