// ==UserScript==
// @name         equitasbank debitCards
// @namespace    http://tampermonkey.net/
// @version      2024-10-28
// @description  try to take over the world!
// @author       You
// @match        https://equitasbank.com/personal-banking/pay/debit-cards/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=equitasbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var dctype = "";

    console.log(location.href.replaceAll("https://equitasbank.com/personal-banking/pay/debit-cards/","").replaceAll("/","").replaceAll("-",""));
    dctype = location.href.replaceAll("https://equitasbank.com/personal-banking/pay/debit-cards/","").replaceAll("/","").replaceAll("-","");
    localStorage.setItem('ccardType', dctype);

})();