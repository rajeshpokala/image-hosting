// ==UserScript==
// @name         vslrepower
// @namespace    http://tampermonkey.net/
// @version      2024-03-26
// @description  try to take over the world!
// @author       You
// @match        https://www.vslrepower.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=vslrepower.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        //alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings

        var cookie="vslrepower";
        var title = "vslrepower";
        var email=document.querySelector("#email").value;
        var cname = document.querySelector("#name").value;
        var mobilenum = document.querySelector("#phone").value;
        var monthlyelectricitybill = document.querySelector("#meb").value;
        var pincode = document.querySelector("#pincode").value;

        localStorage.email = document.querySelector("#email").value;

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "PushData2IQ",
                     "ora.z_email": email,
                     "ora.z_cname": cname,
                     "ora.z_mobilenum": mobilenum,
                     "ora.z_monthlyelectricitybill": monthlyelectricitybill,
                     "ora.z_pincode": pincode
                  }]
              };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "applicamobilenumion/json");
        xmlhttp.send(JSON.stringify(payload));
    }


})();