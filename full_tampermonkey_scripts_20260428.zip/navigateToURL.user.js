// ==UserScript==
// @name         navigateToURL
// @namespace    http://tampermonkey.net/
// @version      2024-09-10
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here for navigateToURL
    //window.ondblclick = function() {window.open('https://www.kotaklife.com/term-insurance/kotak-e-term')};
  //function captureFunction() {
    //  window.open('https://www.kotaklife.com/term-insurance/kotak-e-term');
  //}
    //==============
    // Your code here for add event and element in real time
    // Function to create and start the countdown
    function showCountdown() {
        // Avoid creating multiple timers
        if (document.getElementById("countdown")) return;

        // Create the countdown div with inline styles
        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 15s";

        // Apply inline styles
        countdownDiv.style.fontSize = "24px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #ccc";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "50%";
        countdownDiv.style.right = "20px";
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 15;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.remove(); // remove the div after countdown
                onCountdownComplete();
            }
        }, 1000);
    }

    // Attach double-click event to the document
    document.addEventListener("dblclick", showCountdown);
    function onCountdownComplete() {
        alert("Countdown completed! Triggering the function.");
        // Your custom logic goes here (e.g., redirect, submit form, etc.)
        // For example:
        // document.body.style.backgroundColor = "lightblue";
    }

    // Product 1 variables
let productId1 = "SKU1";
let name1 = "Product Name 1";
let price1 = 1159.99;
let pageUrl1 = "";
let imageUrl1 = "";
let formattedCurrency1 = "₹";
let formattedSalePrice1 = "";

// Product 2 variables
let productId2 = "SKU2";
let name2 = "Product Name 2";
let price2 = 2159.99;
let pageUrl2 = "";
let imageUrl2 = "";
let formattedCurrency2 = "₹";
let formattedSalePrice2 = "";

// Product 3 variables
let productId3 = "SKU3";
let name3 = "Product Name 2";
let price3 = 2159.99;
let pageUrl3 = "";
let imageUrl3 = "";
let formattedCurrency3 = "₹";
let formattedSalePrice3 = "";

// Create the final JSON object
const recommendationsData = {
  recommendations: [
    {
      "Product ID": productId1,
      "Name": name1,
      "Price": price1,
      "Formatted Price": `${formattedCurrency1}${price1.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
      "Page URL": pageUrl1,
      "Image URL": imageUrl1,
      "Formatted Currency": formattedCurrency1,
      "Formatted Sale Price": formattedSalePrice1
    },
    {
      "Product ID": productId2,
      "Name": name2,
      "Price": price2,
      "Formatted Price": `${formattedCurrency2}${price2.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
      "Page URL": pageUrl2,
      "Image URL": imageUrl2,
      "Formatted Currency": formattedCurrency2,
      "Formatted Sale Price": formattedSalePrice2
    },
    {
      "Product ID": productId3,
      "Name": name3,
      "Price": price3,
      "Formatted Price": `${formattedCurrency3}${price3.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
      "Page URL": pageUrl3,
      "Image URL": imageUrl3,
      "Formatted Currency": formattedCurrency3,
      "Formatted Sale Price": formattedSalePrice3
    }
  ]
};

// Output the result
console.log(JSON.stringify(recommendationsData, null, 2));

   // Your code here...

})();