// ==UserScript==
// @name         ACT Corp
// @namespace    http://tampermonkey.net/
// @version      2025-10-24
// @description  try to take over the world!
// @author       Rajesh Pokala
// @match        https://www.actcorp.in/*
// @match        https://soa.actcorp.in/bot/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=actcorp.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    window.userInputs = [];
    document.addEventListener("dblclick", captureAllMessages);

    if(window.location.href == "https://www.actcorp.in/amazon-prime"){
        document.addEventListener("click", function(e) {

            const btn = e.target.closest("a.btn.btn-danger.text-uppercase.w-100.mg-t-38.plandetails");

            if (!btn) return;

            const card = btn.closest(".slider-items, .slider-item, .plan-card, .slick-slide");
            if (!card) return;

            const headingEl = card.querySelector(".heading-plan");
            if (!headingEl) return;

            const planId = headingEl.getAttribute("data-plan-id");
            const planName = headingEl.querySelector("span")?.innerText.trim() || "";
            const speed = headingEl.querySelector("h2")?.innerText.trim() || "";
            const benefit = headingEl.querySelector("p")?.innerText.trim() || "";
            const rate = btn.getAttribute("data-rate") || "";
            localStorage.setItem("planId", planId);
            localStorage.setItem("planName", planName);
            localStorage.setItem("speed", speed);
            localStorage.setItem("benefit", benefit);
            localStorage.setItem("rate", rate);

        }, true);

    }
    if(window.location.href == "https://www.actcorp.in/"){
        var pname = localStorage.planName;
        //alert(pname);
        if(pname != null){
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                console.log('Script loaded successfully:');
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "ACT_addons_pageview"
                    }
                });
            };
            document.head.appendChild(script);
        }
    }
    const urlParams = new URLSearchParams(location.search);
    if (urlParams.has("src")) {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
            console.log('Script loaded successfully:');
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "ACT_PagevisitTracking",
                    "ora.z_src_channel": urlParams.get("src")
                }
            });
        };
        document.head.appendChild(script);
    }

    function captureAllMessages() {
        const nodes = document.querySelectorAll(".messages.msg_sent > p");
        window.userInputs = Array.from(nodes).map(n => n.innerText.trim()).filter(Boolean);

        console.log(window.userInputs);
        triggerFunction();
    }


    function triggerFunction() {
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
            "events": [{
                "ora.z_eventname": "CaptureACTchatbot",
                "ora.z_tag_id": "1",
                "ora.z_chatMessages": window.userInputs
            }]
        };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }

    // Your code here...
})();