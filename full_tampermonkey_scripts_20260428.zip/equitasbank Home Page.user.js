// ==UserScript==
// @name         equitasbank Home Page
// @namespace    http://tampermonkey.net/
// @version      2024-10-03
// @description  try to take over the world!
// @author       You
// @match        https://equitasbank.com
// @icon         https://www.google.com/s2/favicons?sz=64&domain=equitasbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

        var ccardType = localStorage.ccardType;
        if(ccardType != null){
            triggerWP();
        }

function triggerWP() {

     var ccardType = localStorage.ccardType;
     const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        //alert("hello");
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "TriggerWPEquitas",
                "ora.z_email": "kumar.rp1215@gmail.com",
                "ora.z_ccardType": ccardType
            }
        });
    };
    document.head.appendChild(script);
    sessionStorage.clear();
}
    // Your code here...
})();