// ==UserScript==
// @name         thomascook
// @namespace    http://tampermonkey.net/
// @version      2025-04-08
// @description  try to take over the world!
// @author       You
// @match        https://www.thomascook.in/holidays*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=thomascook.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
            window.ondblclick = function() {captureFunction()};

        function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="thomascook";
        var title = "thomascook";
        var eventid = Date.now();

        var email=document.querySelector("#userEmailId").value;
        var phone=document.querySelector("#userMobileNo").value;
        var visited=window.location.href.replaceAll("https://www.thomascook.in/","");
        var packageName=document.querySelector("#packageDetails > div.cms-cls > div > div.pdp_container > div.hide_book_mobile_pdp > div.pdp_flight_heading.container > div.row.px-4 > h1").innerText;
        var packageImg=document.querySelector("#pdpSlider > div > a > img").src;
        var triptDate=document.querySelector("#sidebarDropdownPrice > div.pricing_summary_calc > div.date_of_travel_price > ul > li > span:nth-child(2)").innerText;
        var packagePrice=document.querySelector("#sidebarDropdownPrice > h4 > span:nth-child(3)").innerText.replaceAll(" ",",");
        var travellercount = document.querySelector("#sidebarDropdownPrice > div.pricing_summary_calc > div.no_of_travellers_price > ul > li.no_of_adult_price > span:nth-child(2)").innerText;


        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSupCareInsu",
                    "ora.z_phone": phone,
                    "ora.z_email": email,
                    "ora.z_packageName": packageName,
                    "ora.z_visited": visited,
                    "ora.z_packageImg": packageImg,
                    "ora.z_packagePrice": packagePrice,
                    "ora.z_triptDate": triptDate,
                    "ora.z_travellercount": travellercount,
                    "ora.z_eventid": eventid,
                    "ora.z_custid": "1_139598"
                }
            });
        };
        document.head.appendChild(script);
    }


    // Your code end here...
})();