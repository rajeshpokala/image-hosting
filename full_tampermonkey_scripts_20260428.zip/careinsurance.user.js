// ==UserScript==
// @name         careinsurance
// @namespace    http://tampermonkey.net/
// @version      2025-04-07
// @description  try to take over the world!
// @author       You
// @match        https://www.careinsurance.com/explore/quote-details?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=careinsurance.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        window.ondblclick = function() {captureFunction()};

        function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

            const dataci = dataLayer;

            let dLayerJsonFound = null;

            for (let i = 0; i < dataci.length; i++) {
                if (dataci[i].dLayerJson) {
                    dLayerJsonFound = dataci[i].dLayerJson;
                    break; // Remove this if you want to collect all matches
                }
            }

        var cookie="careinsurance";
        var title = "careinsurance";
        var eventid = Date.now();
        localStorage.desti = dLayerJsonFound["Travelling Country"];

        var email=dLayerJsonFound["Email Id"];
        var phone=dLayerJsonFound["Mobile"];
        var suminsured=dLayerJsonFound["Sum Insured"];
        var tag = "travel-insurance";
        var ssource = "facebook";
        var destination=dLayerJsonFound["Travelling Country"];
        var totmem=document.querySelector("div.edit_details > p > span:nth-child(3)").textContent.replaceAll("Member","");
        var tripStartDate=dLayerJsonFound["Trip Start Date"];
        var tripEndDate=dLayerJsonFound["Trip End Date"];
        var age=dLayerJsonFound["Member1_Age"];
        var duration=document.querySelector("div.edit_details > p > span:nth-child(9)").textContent.replaceAll("Days","");
        var premiumAmount = document.querySelector("#total_price").textContent.replaceAll("₹","");


        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSupCareInsu",
                    "ora.z_phone": phone,
                    "ora.z_email": email,
                    "ora.z_coverAmt": suminsured,
                    "ora.z_tag": ssource,
                    "ora.z_destination": destination,
                    "ora.z_totmem": totmem,
                    "ora.z_tripStartDate": tripStartDate,
                    "ora.z_tripEndDate": tripEndDate,
                    "ora.z_age": age,
                    "ora.z_duration": duration,
                    "ora.z_premiumAmount": premiumAmount,
                    "ora.z_eventid": eventid,
                    "ora.z_custid": "1_139598"
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var email=document.querySelector("#Email_address").value;

        var payload = {
                "static": {
                "wt.co_f": "careinsurance",
                "wt.ti": "careinsurance",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventCareInsu",
                     "ora.z_tag_id": "1",
                     "ora.z_email": email
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // Your code End here...
})();