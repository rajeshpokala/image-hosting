// ==UserScript==
// @name         ACT Game Userscript
// @namespace    http://tampermonkey.net/
// @version      2025-12-22
// @description  try to take over the world!
// @author       You
// @match        https://www.actcorp.in/wifipedia
// @icon         https://www.google.com/s2/favicons?sz=64&domain=actcorp.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "ACT_Gamification"
            }
        });
    }
    document.head.appendChild(script);

})();