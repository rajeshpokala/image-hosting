// ==UserScript==
// @name         cholasecurities ABD
// @namespace    http://tampermonkey.net/
// @version      2025-06-03
// @description  try to take over the world!
// @author       You
// @match        https://www.cholasecurities.com/products-services/equity
// @icon         https://www.google.com/s2/favicons?sz=64&domain=cholasecurities.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        window.ondblclick = function() {showCountdown()};
    var email="kumar.rp1215@gmail.com";

    function showCountdown() {
        // Avoid creating multiple timers
        if (document.getElementById("countdown")) return;

        // Create the countdown div with inline styles
        const countdownDiv = document.createElement("div");
        countdownDiv.id = "countdown";
        countdownDiv.innerText = "Session expire in 15s";

        // Apply inline styles
        countdownDiv.style.fontSize = "24px";
        countdownDiv.style.fontWeight = "bold";
        countdownDiv.style.padding = "20px";
        countdownDiv.style.border = "1px solid #e72229";
        countdownDiv.style.width = "200px";
        countdownDiv.style.textAlign = "center";
        countdownDiv.style.position = "fixed";
        countdownDiv.style.top = "50%";
        countdownDiv.style.right = "20px";
        countdownDiv.style.transform = "translateY(-50%)"; // Centers vertically

        // Add to body
        document.body.appendChild(countdownDiv);

        let timeLeft = 15;

        const timer = setInterval(() => {
            timeLeft--;
            countdownDiv.innerText = `Session expire in ${timeLeft}s`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                countdownDiv.innerText = "Data Captured";
                //countdownDiv.remove(); // remove the div after countdown
                triggerFunction();
            }
        }, 1000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        //var email=document.querySelector("#Email_address").value;

        var payload = {
                "static": {
                "wt.co_f": "careinsurance",
                "wt.ti": "careinsurance",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventChola",
                     "ora.z_tag_id": "1",
                     "ora.z_email": email,
                     "ora.z_monthlyinvestment": document.querySelector("#cost").value,
                     "ora.z_expectedreturnrate": document.querySelector("#intrest").value,
                     "ora.z_period": document.querySelector("#period").value,
                     "ora.z_earn": document.querySelector("#profitlbl").innerText,
                     "ora.z_totalvalue": document.querySelector("#profitlbl1").innerText
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // Your code here...
})();