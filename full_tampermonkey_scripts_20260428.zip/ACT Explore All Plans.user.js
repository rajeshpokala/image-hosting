// ==UserScript==
// @name         ACT Explore All Plans
// @namespace    http://tampermonkey.net/
// @version      2024-10-09
// @description  try to take over the world!
// @author       You
// @match        https://www.actcorp.in/explore-all-plans
// @icon         https://www.actcorp.in/sites/default/files/favicon_1.png
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var Packprice = null;
    var Packname =null;
    var Packspeed = null;

    window.ondblclick = function() {captureFunction()};
    //const element = document.getElementById("edit-submit");
    //element.addEventListener("click", captureFunction);


    function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        const PLoc = document.querySelectorAll('[id^="select2-edit-field-product-locations-target-id"]');
        const select = document.getElementById('edit-city');
        const selectedOption = select.options[select.selectedIndex];
        const cityName = selectedOption.text;
        var eventid = Date.now();
        var Name = document.querySelector("#edit-name").value;
        //var City = document.querySelector("#edit-city").value;
        var Phone = document.querySelector("#edit-phone-number").value;
        var Address = document.querySelector("#place-address-autocomplete-new").value;
        var House = document.querySelector("#edit-do-you-live-in-a-multi-storey-house-new-no").value;
        var PLocation = PLoc[0].innerText;




        alert("Data Captured");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "ACT_ExploreAllPlans",
                    "ora.z_tag": "Plans Explore",
                    "ora.z_email": "veerubravo@gmail.com",
                    "ora.z_Name": Name,
                    "ora.z_City": cityName,
                    "ora.z_Phone": "00919842282592",
                    "ora.z_Address": Address,
                    "ora.z_House": House,
                    "ora.z_PLocation": PLocation,
                    "ora.z_Packprice": Packprice,
                    "ora.z_Packname": Packname,
                    "ora.z_Packspeed": Packspeed,
                    "ora.z_eventid": eventid
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var payload = {
               "events": [{
                     "ora.z_eventname": "Trigger_ExploreAllPlans",
                     "ora.z_tag_id": "1",
                     "ora.z_Phone": "00919842282592",
                     "ora.z_email": "veerubravo@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
const waitForElements = setInterval(() => {
        const radios = document.querySelectorAll('input[type="radio"][name="bundle"]');
        if (radios.length > 0) {
            clearInterval(waitForElements);

            document.addEventListener('change', function(e) {
                const rb = e.target;
                if (!rb.matches('input[type="radio"][name="bundle"]')) return;

                const row = rb.closest('.select-plans-table');
                if (!row) return;

                const titleEl = row.querySelector('h4.text-uppercase.text-yellow.fs-5.fw-bold.mb-1');
                const planName = titleEl ? titleEl.textContent.trim() : '';

                const label = rb.nextElementSibling;
                const price = label?.querySelector('h6.fw-bold')?.textContent.trim() || '';
                const speed = label?.querySelector('.d-md-none .fs-2')?.textContent.trim() || '';
                Packprice = price;
                Packname = planName;
                Packspeed = speed;


            });
        }
    }, 500);
})();