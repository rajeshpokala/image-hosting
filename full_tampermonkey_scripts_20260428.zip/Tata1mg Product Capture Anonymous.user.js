// ==UserScript==
// @name         Tata1mg Product Capture Anonymous
// @namespace    http://tampermonkey.net/
// @version      2025-03-08
// @description  try to take over the world!
// @author       You
// @match        https://www.1mg.com/otc/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=1mg.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    let btn = document.querySelector('button[aria-label="Add to cart"]');
    btn.addEventListener("click", () => { setTimeout(wpcart, 10000); });

    function wpcart(){
        //alert("button clicked");
    const script = document.createElement('script');
    script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
    script.async = true;

    script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        //alert("hello");
        ORA.click({
            "sendSessionInfo": true,
            "data": {
                "ora.z_eventname": "TriggerWP1mgCart"
            }
        });
    };
        document.head.appendChild(script);
        sessionStorage.clear();
    }

    window.ondblclick = function() {if(window.location.href.indexOf("otc") > 0){captureFunction()}};

    function captureFunction() {

     alert("Data Captured ");

        //generic settings
        var pimg = document.querySelector("#container > div > div > div.row.OtcPage__top-container___2JKJ- > div:nth-child(2) > div > div.col-xs-10.ProductImage__preview-container___2oTeX > div > img").src;
        localStorage.setItem('pimg', pimg);
        var pname = document.querySelector("#container > div > div > div.row.OtcPage__top-container___2JKJ- > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > h1").innerText;
        localStorage.setItem('pname', pname);
        var pprice = document.querySelector("#container > div > div > div.row.OtcPage__top-container___2JKJ- > div:nth-child(4) > div:nth-child(1) > div > div.OtcPriceBox__price-box___p13HY > div:nth-child(2) > div").innerText.replaceAll("\nInclusive of all taxes","");
        localStorage.setItem('pprice', pprice);
        localStorage.setItem('purl', window.location.href);

        console.log(pimg + "-"+ pname + "-"+pprice+"-"+localStorage.purl);

        //setTimeout(triggerFunction, 12000);
    }


    // Your code here...

})();