// ==UserScript==
// @name         genertel Multi-Branch Investment
// @namespace    http://tampermonkey.net/
// @version      2025-01-07
// @description  try to take over the world!
// @author       You
// @match        https://www.genertel.it/piano-investimento-multiramo
// @icon         https://www.google.com/s2/favicons?sz=64&domain=genertel.it
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

	 // Get all the <li> elements
    const listItems = document.querySelectorAll('li');

    // Add a click event listener to each <li>
    listItems.forEach(item => {
        item.addEventListener('click', function(event) {
            const clickedEm = this.querySelectorAll('em');
            console.log('Clicked EM:', clickedEm[0].innerText);
            localStorage.setItem('ctype', clickedEm[0].innerText)
        });
    });

    // Your code here...
})();