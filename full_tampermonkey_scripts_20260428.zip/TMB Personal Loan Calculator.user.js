// ==UserScript==
// @name         TMB Personal Loan Calculator
// @namespace    http://tampermonkey.net/
// @version      2025-02-10
// @description  try to take over the world!
// @author       You
// @match        https://www.tmb.in/OnlineEMICalculator
// @icon         https://www.tmb.in/assets/images/favicon.png
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="TMBank";
        var title = "TMBank";
        var eventid = Date.now();
        var email="kumar.rp1215@gmail.com";
        var phone="00918939953499";
        var tag = "TMB personal loan";
        var loanAmtRequested = document.querySelector("#loan-amt-personal-input").value.replaceAll(",","");
        var monEMI = document.querySelector("#emi_amt_personal").innerText.replaceAll("₹ ","").replaceAll(",","");
        var roi = document.querySelector("#interest-rate-personal-input").value;
        var tenure = document.querySelector("#tenure-months-personal-input").value;

        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSuppTMB",
                    "ora.z_email": email,
                    "ora.z_phone": phone,
                    "ora.z_tag": tag,
                    "ora.z_loanAmtRequested": loanAmtRequested,
                    "ora.z_monEMI": monEMI,
                    "ora.z_roi": roi,
                    "ora.z_tenure": tenure,
                    "ora.z_eventid": eventid,
                    "ora.z_interestarea": "TMB Personal Loan"
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "TMBank",
                "wt.ti": "TMBank",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventTMB",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // Your code ends

})();