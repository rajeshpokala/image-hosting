// ==UserScript==
// @name         TestEventDAta
// @namespace    http://tampermonkey.net/
// @version      2024-12-18
// @description  try to take over the world!
// @author       You
// @match        https://www.oracle.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=oracle.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
        //alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        var eventid = Date.now();

        //generic settings
        var email="kumar.rp1215+165065@gmail.com";
        var CustomerID="1_165065";
        var title = "eventdata";


        var payload = {
            "static": {
                "wt.ti": title,
                "domain": "www.oracle.come"
            },
            "events": [{
                "ora.z_eventname": "TriggerEventDataPIPE",
                "ora.z_email": email,
                "ora.z_CustomerID": CustomerID,
                "ora.z_interestarea": "Car loan",
                "ora.z_phone": "00919090909090",
                "ora.z_tag":"loan",
                "ora.z_eventid": eventid
            }]
        };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
})();