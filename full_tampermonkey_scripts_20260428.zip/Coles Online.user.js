// ==UserScript==
// @name         Coles Online
// @namespace    http://tampermonkey.net/
// @version      2024-11-18
// @description  try to take over the world!
// @author       You
// @match        https://www.coles.com.au/browse/liquor*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=coles.com.au
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
         alert("Data Captured ");

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "user.eventname": "TriggerColesWPPage",
                    "user.email": "kumar.rp1215@gmail.com"
                }
            });
        };
        document.head.appendChild(script);


    // Your code here...
})();