// ==UserScript==
// @name         SMFG EMI CALC
// @namespace    http://tampermonkey.net/
// @version      2024-02-23
// @description  try to take over the world!
// @author       You
// @match        https://www.smfgindiacredit.com/personal-loan-emi-calculator.aspx
// @icon         https://www.google.com/s2/favicons?sz=64&domain=smfgindiacredit.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ondblclick = function() {captureFunction()};

    function captureFunction() {

        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        //generic settings
        var email="kumar.rp1215@gmail.com";
        var cookie="SMFG";
        var title = "SMFG";
        var loanAmt = document.getElementsByClassName("rc-slider-handle")[0].ariaValueNow;
        var croi = document.getElementsByClassName("rc-slider-handle")[1].ariaValueNow;
        var ctenure = document.getElementsByClassName("rc-slider-handle")[2].ariaValueNow;
        var monthEMI = document.getElementsByClassName("eligibleAmt calc-amt")[0].innerText.replaceAll(",","").trim();

        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": "TriggerSuppCALCSMFG",
                     "ora.z_email": email,
                     "ora.z_loanAmt": loanAmt,
                     "ora.z_monthEMI": monthEMI,
                     "ora.z_roi": croi,
                     "ora.z_tenure": ctenure
                  }]
              };

        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "SMFG",
                "wt.ti": "SMFG",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventCALCSMFG",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
})();