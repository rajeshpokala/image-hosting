// ==UserScript==
// @name         sharekhan
// @namespace    http://tampermonkey.net/
// @version      2025-09-15
// @description  try to take over the world!
// @author       You
// @match        https://www.sharekhan.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=sharekhan.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    function saveSmartSearch() {
        const div = document.querySelector("div.row.smart_search");
        if (div) {
            localStorage.setItem("smart_search_html", div.outerHTML);
        }
    }
    function insertSmartSearch() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        script.onload = () => {
             console.log('Script loaded successfully:');
             ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "WP_sharekhanhomepage"
                }
            });
        };
        document.head.appendChild(script);
        sessionStorage.clear();

    }

    // Run after page load
    window.addEventListener("load", () => {
        if(window.location.href.startsWith("https://www.sharekhan.com/ipo/") == true){
            setTimeout(saveSmartSearch, 4000);
        }
        if(window.location.href == "https://www.sharekhan.com/" && localStorage.smart_search_html.length > 0){
            const miraeLogo = document.querySelector('a[aria-label="Mirae Asset Global Website"]');
            if (miraeLogo) {
                miraeLogo.remove();
                console.log("Removed Mirae Asset Global Website link");
            } else {
                console.log("Mirae Asset logo block not found");
            }
            setTimeout(insertSmartSearch, 1000);
        }
    });
    // Your code here...
})();