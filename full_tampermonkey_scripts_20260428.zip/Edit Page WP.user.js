// ==UserScript==
// @name         Edit Page WP
// @namespace    http://tampermonkey.net/
// @version      2025-07-08
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @require      https://raw.githubusercontent.com/rajeshpokala/jscode/refs/heads/main/addWPscript.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // your code ends here...
})();