// ==UserScript==
// @name         tvscredit homepage
// @namespace    http://tampermonkey.net/
// @version      2025-07-15
// @description  try to take over the world!
// @author       You
// @match        https://www.tvscredit.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tvscredit.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    //const slide1 = document.querySelector('.slider-container');
    //slide1.remove();
    //const slide = document.querySelector('.swiper-slide');
    //slide.style.backgroundImage = `url("http://r-d7k13dz-8000005.oraclersys.com/assets/responsysimages/content/demo028/tvscredit_wp.png")`;

    if(location.href.indexOf("https://www.tvscredit.com/loans/two-wheeler-loans/") >= 0 )
    {
        // Wait for the DOM to load
        //alert("here");
        document.addEventListener("DOMContentLoaded", function() {
            alert("here");
            const container = document.querySelector('.interest_rate_charge_btn.text-center.pdt-1.fadeIn.wow.animated.animated');

            // Ensure the container uses flexbox for horizontal layout
            container.style.display = 'flex';
            container.style.justifyContent = 'center';
            container.style.gap = '10px'; // space between buttons
            container.style.flexWrap = 'wrap'; // responsive wrapping if needed

            // Create the new button
            const newButton = document.createElement('a');
            newButton.className = 'blue_btn';
            newButton.href = '#'; // update this link as needed
            newButton.target = '_self';
            newButton.setAttribute('aria-label', 'Check Interest Rate in Real Time');
            newButton.textContent = 'Abandon';

            // Add a click function
            newButton.addEventListener('click', function (event) {
                event.preventDefault(); // prevent page jump
                alert('Lead data captured');
                captureFunction();
                sendlead("abandon");
            });

            // Create the new button
            const newButton1 = document.createElement('a');
            newButton1.className = 'blue_btn';
            newButton1.href = '#'; // update this link as needed
            newButton1.target = '_self';
            newButton1.setAttribute('aria-label', 'Check Interest Rate in Real Time');
            newButton1.textContent = 'Apply Now';

            // Add a click function
            newButton1.addEventListener('click', function (event) {
                event.preventDefault(); // prevent page jump
                alert('Apply now');
                sendlead("applynow");
            });

            // Append the button
            container.appendChild(newButton);
            container.appendChild(newButton1);
        });

    }

    if(window.location.href.indexOf("https://www.tvscredit.com/loans/two-wheeler-loans/?n=") == 1000 )
    {
        // Wait for the DOM to load
        //alert("here");
        const nValue = new URLSearchParams(window.location.search).get("n");
        if(nValue){
            console.log(nValue);
            window.addEventListener('load', function () {
                const element = document.querySelector('ul.bnr_ul');
                document.querySelector('.product-banner-content h1')?.remove();
                const h1element = document.querySelector("div.product-banner-content > div > h2");
                if (element) {
                    element.remove();
                    h1element.innerHTML = nValue + ", greetings and thank you for your interest in TVS Credit Two-Wheeler Loan";
                }
            });

        }

    }
    if(window.location.href.indexOf("https://www.tvscredit.com/loans/two-wheeler-loans/?n=") >= 0 )
    {
        const nValue = new URLSearchParams(window.location.search).get("n");
        if(nValue){
            const script = document.createElement('script');
            script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
            script.async = true;

            script.onload = () => {
                // Code to execute after the script has loaded
                console.log('Script loaded successfully:');
                //alert("hello");
                ORA.click({
                    "sendSessionInfo": true,
                    "data": {
                        "ora.z_eventname": "TriggerloanpagetvsC"
                    }
                });
            };
            document.head.appendChild(script);
        }
    }

    if(window.location.href.startsWith("https://www.tvscredit.com/cards/instacard/"))
    {
        window.addEventListener('scroll', () => {
            let scrper = (document.documentElement.scrollTop + document.body.scrollTop) /
                (document.documentElement.scrollHeight - document.documentElement.clientHeight) * 100;

            scrper = Math.round(scrper);
            if (scrper >= 30 && scrper <= 36) {
                console.log("Customer scrolled up to " + scrper + " %");
                localStorage.setItem('cardtype', "instacard");
            }
        });

    }

    if(location.href.indexOf("/special123offers/") > 0)
    {
        alert("offers1");
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully: Offers Page');
            //alert("hello");
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerofferpagetvsC",
                    "ora.z_tag": "tamil nadu"
                }
            });
        };
        document.head.appendChild(script);
    }


    if(window.location.href == "https://www.tvscredit.com/")
    {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;
        var chkdat = localStorage.cardtype;

        script.onload = () => {
            // Code to execute after the script has loaded
            if(chkdat != null){
            console.log('Script loaded successfully:');
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerHometvsC",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_tag": "Home Page"
                }
            });
            }
        };
        document.head.appendChild(script);
    }

    function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var eventid = Date.now();
        var email="kumar.rp1215@gmail.com";
        var phone="00918939953499";
        var tag = "Two Wheeler Loans";
        var loanAmtRequested = document.querySelector("#princAmtTwo").textContent.replaceAll(",","");
        var tCost = document.querySelector("#price").textContent.replaceAll(",","");
        var roi = document.querySelector("#interest_rate").value.replaceAll("%","");
        var tenure = document.querySelector("#tenure").value;
        var variantName = document.querySelector('#variant_emi').options[document.querySelector('#variant_emi').selectedIndex].text;
        var stateVal = document.querySelector("#state_val_emi").options[document.querySelector('#state_val_emi').selectedIndex].text;

        //alert("Data Captured ");
        script.onload = () => {
            // Code to execute after the script has loaded
            console.log('Script loaded successfully:');
            ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSuppTVSC",
                    "ora.z_email": email,
                    "ora.z_phone": phone,
                    "ora.z_tag": tag,
                    "ora.z_loanAmtRequested": loanAmtRequested,
                    "ora.z_roi": roi,
                    "ora.z_tenure": tenure,
                    "ora.z_tCost": tCost,
                    "ora.z_variantName": variantName,
                    "ora.z_stateVal": stateVal,
                    "ora.z_eventid": eventid,
                    "ora.z_loantype": "Two Wheeler Loan"
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
            "static": {
                "wt.co_f": "tvscredit",
                "wt.ti": "tvscredit",
            },
            "events": [{
                "ora.z_eventname": "TriggerEventTVS",
                "ora.z_tag_id": "1",
                "ora.z_email": "kumar.rp1215@gmail.com"
            }]
        };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    function sendlead(qtype) {
        var urlvariable;
        urlvariable = "text";
        var sloanAmtRequested = document.querySelector("#princAmtTwo").textContent.replaceAll(",","");
        var stCost = document.querySelector("#price").textContent.replaceAll(",","");
        var sroi = document.querySelector("#interest_rate").value.replace(/\.\d+|%/g, "");
        var stenure = document.querySelector("#tenure").value;
        var svariantName = document.querySelector('#variant_emi').options[document.querySelector('#variant_emi').selectedIndex].text;
        var sstateVal = document.querySelector("#state_val_emi").options[document.querySelector('#state_val_emi').selectedIndex].text;
        var semi = document.querySelector("#lblEMIAmt").textContent.replaceAll(",","");
        var ItemJSON;

        //var URL = "https://emkv-test.fa.us2.oraclecloud.com/crmRestApi/resources/11.13.18.05/leads";
        //Your URL
        var URL = "https://fa-esll-dev20-saasfademo1.ds-fa.oraclepdemos.com/crmRestApi/resources/11.13.18.05/leads";
        //var URL = "https://fa-esll-dev21-saasfademo1.ds-fa.oraclepdemos.com/fscmUI/redwood/cx-sales/application/container/leads";

        var xmlhttp = new XMLHttpRequest();
        var raw = "";

        if(qtype == "abandon"){
            //alert(1);
            raw = JSON.stringify({ Rank: "HOT", BusinessUnitId: "300000001223323", Description: "TVSCredit Leadbywebpage", PrimaryContactId: "300000140718899", PrimaryContactPartyName: "Rajest Pokala", PrimaryContactCountry: "IN", PrimaryContactAddress1: "Porur", PrimaryContactAddress2: "Porur", PrimaryContactCity: "Chennai", PrimaryContactPostalCode: "600116", PrimaryContactState: "MH", PrimaryContactEmailAddress: "rajesh.kumar.pokala@oracle.com", VehicleVari_c: svariantName, State_c: sstateVal, LoanAmount_c: sloanAmtRequested, RateOfInterest_c: sroi, Tenure_c: stenure, MonthlyLoanEMI_c: semi,Name: "Rajesh Pokala - "+ svariantName,DealAmount:sloanAmtRequested});
        }else if(qtype == "applynow") {
            raw = JSON.stringify({ Rank: "HOT", BusinessUnitId: "300000001223323", Description: "TVSCredit Leadbywebpage", PrimaryContactId: "300000140718899", PrimaryContactPartyName: "Rajesh Pokala", PrimaryContactCountry: "IN", PrimaryContactAddress1: "Porur", PrimaryContactAddress2: "Porur", PrimaryContactCity: "Chennai", PrimaryContactPostalCode: "600116", PrimaryContactState: "MH", PrimaryContactEmailAddress: "rajesh.kumar.pokala@oracle.com", VehicleVari_c: svariantName, State_c: sstateVal, LoanAmount_c: sloanAmtRequested, RateOfInterest_c: sroi, Tenure_c: stenure, MonthlyLoanEMI_c: semi,StatusCode: "QUALIFIED",Name: "Rajesh Pokala - "+ svariantName,DealAmount:sloanAmtRequested,ChannelType: "WEB"});
        }

        xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
        xmlhttp.open("POST", URL, false);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        // xmlhttp.setRequestHeader("Authorization", "Basic bGlzYS5qb25lczprVFA3dyM3Xg==");
        xmlhttp.setRequestHeader('Authorization', 'Basic ' + window.btoa('john.dunbar:C5h?b2J*'));
        xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
        alert(raw);
        console.log(raw);
        xmlhttp.send(raw);
        alert("Response Text - " + xmlhttp.responseText);
        //document.getElementById("div").innerHTML = xmlhttp.statusText + ":" + xmlhttp.status + "<BR><textarea rows='100' cols='100'>" + xmlhttp.responseText + "</textarea>";
    }
    function callbackFunction(xmlhttp) {
        //alert(xmlhttp.responseXML);
    }
    // Your code here...

})();