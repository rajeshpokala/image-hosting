// ==UserScript==
// @name         RBL BANK CALC
// @namespace    http://tampermonkey.net/
// @version      2025-02-11
// @description  try to take over the world!
// @author       You
// @match        https://www.rblbank.com/personal-loan-calculator
// @icon         https://www.google.com/s2/favicons?sz=64&domain=rblbank.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

    const element = document.getElementById("btn_calculate");
    element.addEventListener("click", captureFunction);


        function captureFunction() {

        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="RBLBank";
        var title = "RBLBank";
        var eventid = Date.now();

        var email="kumar.rp1215@gmail.com";
        var phone="00918939953499";
        var loanAmtRequested = document.querySelector("#DepAmt").innerText.replaceAll(",","");
        var tag = "rbl personal-loan";
        var monEMI = document.querySelector("#emi").innerText.replaceAll("₹ ","");
        var roi = document.querySelector("#loanRate").innerText;
        var tenure = document.querySelector("#tenureVal").innerText;

        alert("Data Captured ");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "TriggerSuppKB",
                    "ora.z_email": "kumar.rp1215@gmail.com",
                    "ora.z_email": email,
                    "ora.z_phone": phone,
                    "ora.z_loanAmtRequested": loanAmtRequested,
                    "ora.z_tag": tag,
                    "ora.z_monEMI": monEMI,
                    "ora.z_roi": roi,
                    "ora.z_tenure": tenure,
                    "ora.z_eventid": eventid,
                    "ora.z_interestarea": "RBL Personal Loan"
                }
            });
        };
        document.head.appendChild(script);
        setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "RBLBank",
                "wt.ti": "RBLBank",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventKB",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "kumar.rp1215@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    // Your code ends
})();