// ==UserScript==
// @name         ACT Unity C360
// @namespace    http://tampermonkey.net/
// @version      2025-08-28
// @description  try to take over the world!
// @author       Rajesh Kumar Pokala
// @match        https://indiasales.cxunity.ocs.oraclecloud.com/data*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=oraclecloud.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    let hasRun = false;


     window.ondblclick = function() {if (!hasRun) {updateCustomerId(); hasRun = true;} replacePurchaseReturn(); updateProductAffinity(); replacePapularDay(); replacePapularMonth(); updateOverview(); updatechannelEngagement(); replacepopularResponseDay(); replacepopularResponseMonth();


                                   };


    function updateCustomerId() {
        //alert("here");
        document.querySelector("#ojCxuAskOracle_ask-oracle > div.oj-cxu-rw-ask-oracle-page-container > div > div > oj-module > profile-details > div > div.cxu-white-panel.oj-cxu-header-shadow.oj-cxu-container.profile-view > div.oj-cxu-left-panel > div.oj-flex > div:nth-child(2) > div > span.id-label").innerText = "Customer ID";
        document.querySelector("#ojCxuAskOracle_ask-oracle > div.oj-cxu-rw-ask-oracle-page-container > div > div > oj-module > profile-details > div > div.cxu-white-panel.oj-cxu-header-shadow.oj-cxu-container.profile-view > div.oj-cxu-left-panel > div.oj-flex > div:nth-child(2) > div > span.id-value.oj-sm-margin-6x-start").innerText = "5567980";

        document.querySelectorAll(".picto_layout .picto_chart_padding").forEach(el => {
                                        el.remove();
                                    });

                                    document.querySelectorAll(".metric-bold").forEach(el => {
                                        el.style.height = "80px";
                                        el.style.lineHeight = "30px";
                                    });


                                    let labels = document.querySelectorAll(".picto_layout .label_padding span:first-child");
        labels.forEach(label => {
            label.style.fontSize = "18px";
            label.style.fontWeight = "500";
            label.style.color = "#333";
        });

                                    if (labels.length >= 3) {
                                        labels[0].textContent = "Current Plan";
                                        labels[1].textContent = "Speed";
                                        labels[2].textContent = "Monthly Bill";
                                        labels[3].textContent = "Data Consumed";
                                        //labels[4].textContent = "Avg Consumption";
                                    }

                                    // 2. Set values
                                    let metrics = document.querySelectorAll(".metric-bold span");
                                    let met = document.querySelectorAll(".profile-details .metric-bold");

                                    //met.style.height = "80px";

                                    if (metrics.length >= 3) {
                                        metrics[0].innerHTML = "<span style='font-size:18px;'>The Starter PACK</span>";
                                        metrics[1].innerHTML = "<span style='font-size:18px;'>600 Mbps,</span>"+ "<span style='font-size:14px;'> Unlimited</span>";
                                        metrics[2].innerHTML = "<span style='font-size:18px;'>₹ 2,049</span>";
                                        metrics[3].innerHTML = "<span style='font-size:18px;'>450 GB / 600 GB</span>";
                                        //metrics[4].innerHTML = "<span style='font-size:18px;'>High</span>";
                                    }

                                    // 3. Add colored blocks under each metric
                                    function addBlocks(container, count, color) {
                                        let blockWrapper = document.createElement("div");
                                        blockWrapper.style.marginTop = "6px";
                                        blockWrapper.style.display = "flex";
                                        blockWrapper.style.gap = "6px";

                                        for (let i = 0; i < count; i++) {
                                            let block = document.createElement("div");
                                            block.style.width = "24px";
                                            block.style.height = "24px";
                                            block.style.borderRadius = "0px";
                                            block.style.backgroundColor = color;
                                            blockWrapper.appendChild(block);
                                        }
                                        container.appendChild(blockWrapper);
                                    }

                                    if (metrics.length >= 3) {
                                        addBlocks(metrics[0].parentElement, 3, "#C54A39");
                                        addBlocks(metrics[1].parentElement, 3, "#C54A39");
                                        addBlocks(metrics[2].parentElement, 2, "#C54A39");
                                        addBlocks(metrics[3].parentElement, 4, "#C54A39");
                                        //addBlocks(metrics[4].parentElement, 5, "#C54A39");
                                    }

                                    document.querySelectorAll("oj-avatar").forEach(avatar => {
                                        while (avatar.firstChild) {
                                            avatar.removeChild(avatar.firstChild);
                                        }

                                        const img = document.createElement("img");
                                        img.src = "http://r-d7k13dz-8000005.oraclersys.com/assets/responsysimages/content/demo028/c360profile.png";
                                        img.alt = "User Avatar";
                                        img.style.width = "100%";
                                        img.style.height = "100%";
                                        img.style.objectFit = "cover";
                                        img.style.borderRadius = "8px";

                                        // Append new image
                                        avatar.appendChild(img);

                                        // Force visibility override (bypass Redwood JET CSS rule)
                                        avatar.style.visibility = "visible";
                                    });

    }

    function replacePurchaseReturn() {
        const purchaseCard = document.querySelector("#purchaseReturn");

        if (!purchaseCard) return;

        // Change header text
        const header = purchaseCard.querySelector(".header");
        if (header) header.textContent = "Recent Bill Details";

        // Replace chart-body with inline styled table
        const chartBody = purchaseCard.querySelector(".chart-body");
        if (chartBody) {
            chartBody.innerHTML = `
  <div style="background-color:#f5f5f5; border:1px solid #ddd; border-radius:6px; padding:10px; font-family:Arial, sans-serif; max-width:100%;">
    <table style="width:100%; border-collapse:collapse; font-size:14px;">
      <thead>
        <tr style="background-color:#C54A39; color:#fff;">
          <th style="padding:10px; border:1px solid #ddd;">Month</th>
          <th style="padding:10px; border:1px solid #ddd;">Invoice No</th>
          <th style="padding:10px; border:1px solid #ddd;">Bill Amount</th>
          <th style="padding:10px; border:1px solid #ddd;">Status</th>
          <th style="padding:10px; border:1px solid #ddd;">Payment Date</th>
          <th style="padding:10px; border:1px solid #ddd;">Mode</th>
        </tr>
      </thead>
      <tbody>
        <tr style="background-color:#fff;">
          <td style="padding:8px; border:1px solid #ddd;">Oct 2025</td>
          <td style="padding:8px; border:1px solid #ddd;">ACT987654</td>
          <td style="padding:8px; border:1px solid #ddd;">₹1,249</td>
          <td style="padding:8px; border:1px solid #ddd; color:green;">Paid</td>
          <td style="padding:8px; border:1px solid #ddd;">05-Oct-2025</td>
          <td style="padding:8px; border:1px solid #ddd;">UPI</td>
        </tr>
        <tr style="background-color:#f9f9f9;">
          <td style="padding:8px; border:1px solid #ddd;">Sep 2025</td>
          <td style="padding:8px; border:1px solid #ddd;">ACT983421</td>
          <td style="padding:8px; border:1px solid #ddd;">₹1,249</td>
          <td style="padding:8px; border:1px solid #ddd; color:green;">Paid</td>
          <td style="padding:8px; border:1px solid #ddd;">07-Sep-2025</td>
          <td style="padding:8px; border:1px solid #ddd;">AutoPay</td>
        </tr>
        <tr style="background-color:#fff;">
          <td style="padding:8px; border:1px solid #ddd;">Aug 2025</td>
          <td style="padding:8px; border:1px solid #ddd;">ACT979812</td>
          <td style="padding:8px; border:1px solid #ddd;">₹1,249</td>
          <td style="padding:8px; border:1px solid #ddd; color:green;">Paid</td>
          <td style="padding:8px; border:1px solid #ddd;">09-Aug-2025</td>
          <td style="padding:8px; border:1px solid #ddd;">Credit Card</td>
        </tr>
      </tbody>
    </table>

</div>
      `;
        }
    }

    function replacePapularDay() {
    const card = document.querySelector("#papularDay");
    if (!card) return;

    // Change header
    const header = card.querySelector(".header");
    if (header) {
      header.textContent = "Customer Insights";
    }

    // Replace inner content with Top product style table
    const charts = card.querySelector(".charts");
    if (charts) {
      charts.innerHTML = `<br>
        <table style="width:100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 16px;">
          <tr style="border-bottom:1px solid #ddd; background:#f9f9f9;">
            <td style="padding:10px; font-weight:bold; color:#333;">Churn Score</td>
            <td style="padding:10px; color:green; font-weight:bold;">0.1</td>
          </tr>
          <tr style="border-bottom:1px solid #ddd;">
            <td style="padding:10px; font-weight:bold; color:#333;">Next Best Action</td>
            <td style="padding:10px; color:#444;">Upgrade / Retain / Cross-Sell</td>
          </tr>
          <tr style="border-bottom:1px solid #ddd; background:#f9f9f9;">
            <td style="padding:10px; font-weight:bold; color:#333;">Next Best Offer</td>
            <td style="padding:10px; color:#007ACC; font-weight:bold;">Upgrade to 1 Gbps for ₹200 more</td>
          </tr>
          <tr>
            <td style="padding:10px; font-weight:bold; color:#333;">Fatigue Segment</td>
            <td style="padding:10px; color:purple; font-weight:bold;">Just Right</td>
          </tr>
        </table>
      `;
    }
  }

    function replacePapularMonth() {
    const card = document.querySelector("#papularMonth");
    if (!card) return;

    // Change header
    const header = card.querySelector(".header");
    if (header) {
      header.textContent = "Customer Preferences";
      header.style.fontSize = "18px";
      header.style.fontWeight = "bold";
      header.style.color = "#1A5276";
    }

    // Replace charts content with styled table
    const charts = card.querySelector(".charts");
    if (charts) {
      charts.innerHTML = `<br>
        <table style="width:100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 16px;">
          <tr style="border-bottom:1px solid #e0e0e0; background:#f4f6f7;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Preferred Channel</td>
            <td style="padding:12px; color:#E67E22; font-weight:bold;">Email</td>
          </tr>
          <tr style="border-bottom:1px solid #e0e0e0;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Preferred Time</td>
            <td style="padding:12px; color:#28B463; font-weight:bold;">5:00 PM</td>
          </tr>
          <tr style="background:#f4f6f7;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Preferred Day</td>
            <td style="padding:12px; color:#8E44AD; font-weight:bold;">Monday</td>
          </tr>
        </table>
      `;
    }
  }

    function updateProductAffinity() {
        const card = document.querySelector("#productAffinity");
        if (!card) return;

        // Update header style
        const header = card.querySelector(".header");
        if (header) {
            header.textContent = "Account Details";
            header.style.fontSize = "18px";
            header.style.fontWeight = "bold";
            header.style.color = "#1A5276";
        }

        // Replace chart-body with styled table
        const body = card.querySelector(".chart-body");
        if (body) {
            body.innerHTML = `<br>
        <table style="width:100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 16px;">
          <tr style="border-bottom:1px solid #e0e0e0; background:#f4f6f7;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Invoice Date</td>
            <td style="padding:12px; color:#E74C3C; font-weight:bold;">27th Oct, 2025</td>
          </tr>
          <tr>
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Due Date</td>
            <td style="padding:12px; color:#2980B9; font-weight:bold;">10th Nov, 2025</td>
          </tr>
          <tr style="border-bottom:1px solid #e0e0e0; background:#f4f6f7;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Plan Name</td>
            <td style="padding:12px; color:#E74C3C; font-weight:bold;">The Starter PACK</td>
          </tr>
          <tr>
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Services</td>
            <td style="padding:12px; color:#2980B9; font-weight:bold;">ACT Stream TV+, 1 Gaming Booster Pack</td>
          </tr>
          <tr style="border-bottom:1px solid #e0e0e0; background:#f4f6f7;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Status</td>
            <td style="padding:12px; color:#E74C3C; font-weight:bold;">Active</td>
          </tr>
        </table>
      `;
        }
    }

 function updateOverview() {
        const card = document.querySelector("#overView");
        if (!card) return;

        // Update header style
        const header = card.querySelector(".header");
        if (header) {
            header.textContent = "Overview";
            header.style.fontSize = "18px";
            header.style.fontWeight = "bold";
            header.style.color = "#1A5276";
        }

        // Replace chart-body with styled table
        const body = card.querySelector(".chart-body");
        if (body) {
            body.innerHTML = `<br>
      <div class="chart-body">
        <div class="oj-flex">
          <div class="oj-flex-item individual-item">Open Rate for Email</div>
          <div class="oj-flex-bar-end individual-item">80%</div>
        </div>
        <div class="oj-flex">
          <div class="oj-flex-item individual-item">Click Rate for Email</div>
          <div class="oj-flex-bar-end individual-item">50%</div>
        </div>
        <div class="oj-flex">
          <div class="oj-flex-item individual-item">SMS Delivery Rate</div>
          <div class="oj-flex-bar-end individual-item">90%</div>
        </div>
        <div class="oj-flex">
          <div class="oj-flex-item individual-item">Mobile App</div>
          <div class="oj-flex-bar-end individual-item">60%</div>
        </div>
        <div class="oj-flex">
          <div class="oj-flex-item individual-item">WhatsApp Engagement</div>
          <div class="oj-flex-bar-end individual-item">30%</div>
        </div>
      </div>
      `;
        }
    }
    function updatechannelEngagement() {
        const card = document.querySelector("#channelEngagement");
        if (!card) return;

        // Update header style
        const header = card.querySelector(".header");
        if (header) {
            header.textContent = "Customer Activity";
            header.style.fontSize = "18px";
            header.style.fontWeight = "bold";
            header.style.color = "#1A5276";
        }

        // Replace chart-body with styled table
        const body = card.querySelector(".charts");
        if (body) {
            body.innerHTML = `<br>
      <table style="width:100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 16px;">
          <tr style="border-bottom:1px solid #e0e0e0; background:#f4f6f7;">
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Mobile App installed</td>
            <td style="padding:12px; color:#E74C3C; font-weight:bold;">Yes</td>
          </tr>
          <tr>
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">App version </td>
            <td style="padding:12px; color:#2980B9; font-weight:bold;">iOS 15</td>
          </tr>
          <tr>
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">last Digital activity</td>
            <td style="padding:12px; color:#28B463; font-weight:bold;">Upgrade Plan</td>
          </tr>
		  <tr>
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Opt in</td>
            <td style="padding:12px; color:#28B463; font-weight:bold;">Yes</td>
          </tr>
          <tr>
            <td style="padding:12px; font-weight:bold; color:#2C3E50;">Avg Consumption</td>
            <td style="padding:12px; color:#28B463; font-weight:bold;">High</td>
          </tr>
        </table>
      `;
        }
    }

    function replacepopularResponseDay() {
        const popularResponseDayCard = document.querySelector("#popularResponseDay");

        if (!popularResponseDayCard) return;

        // Change header text
        const header = popularResponseDayCard.querySelector(".header");
        if (header) header.textContent = "SR Details";

        // Replace chart-body with inline styled table
        const chartBody = popularResponseDayCard.querySelector(".charts");
        if (chartBody) {
            chartBody.innerHTML = `
        <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif; font-size:14px;">
          <thead>
            <tr style="background-color:#C54A39; color:#fff;">
              <th style="padding:8px 12px; border:1px solid #ddd; text-align:left;">SR No.</th>
              <th style="padding:8px 12px; border:1px solid #ddd; text-align:left;">Status</th>
              <th style="padding:8px 12px; border:1px solid #ddd; text-align:left;">Date</th>
              <th style="padding:8px 12px; border:1px solid #ddd; text-align:left;">Request Type</th>
			  <th style="padding:8px 12px; border:1px solid #ddd; text-align:left;">Reported By</th>
			  <th style="padding:8px 12px; border:1px solid #ddd; text-align:left;">Diagnosis Summary</th>
            </tr>
          </thead>
          <tbody>
            <tr>
      <td style="padding:8px 12px; border:1px solid #ddd;">ACTSR1045921</td>
      <td style="padding:8px 12px; border:1px solid #ddd; color:green;">Resolved</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">2025-10-26</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">Slow Internet Speed</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">Customer</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">Router rebooted, fiber signal normalized.</td>
    </tr>
    <tr>
      <td style="padding:8px 12px; border:1px solid #ddd;">ACTSR1045720</td>
      <td style="padding:8px 12px; border:1px solid #ddd; color:orange;">In Progress</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">2025-10-27</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">Connectivity Issue</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">Call Center</td>
      <td style="padding:8px 12px; border:1px solid #ddd;">Line check scheduled for technician visit.</td>
    </tr>

          </tbody>
      `;
        }
    }

    function replacepopularResponseMonth() {
        const popularResponseMonthCard = document.querySelector("#popularResponseMonth");

        if (!popularResponseMonthCard) return;

        // Change header text
        const header = popularResponseMonthCard.querySelector(".header");
        if (header) header.textContent = "";

        // Replace chart-body with inline styled table
        const chartBody = popularResponseMonthCard.querySelector(".charts");
        if (chartBody) {
            chartBody.innerHTML = `<br>
      `;
        }
    }
    // Your code here...
})();