// ==UserScript==
// @name         stockholding
// @namespace    http://tampermonkey.net/
// @version      2024-07-17
// @description  try to take over the world!
// @author       You
// @match        https://www.stockholding.com/mutual-fund-types.php
// @icon         https://www.google.com/s2/favicons?sz=64&domain=stockholding.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
           window.ondblclick = function() {captureFunction()};
    function captureFunction() {
        alert("Data Captured ");
        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
        var url = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";
        //generic settings
        var email="colin.rodrigues@oracle.com";
        var cookie="StockHolding";
        var title = "MutualFunds";
        var firstname = document.querySelector("#name").value;
        var lastname = document.querySelector("#lastName").value;
        var mobilenumber = document.querySelector("#mobileno").value;
        var state = document.querySelector("#state").value;
        var city = document.querySelector("#city").value;
        var pincode = document.querySelector("#pincode").value;
        var imgurl = document.querySelector("#carouselExampleIndicators > div > div > picture > img").src;
        var payload = {
                "static": {
                "wt.co_f": cookie,
                "wt.ti": title,
               },
               "events": [{
                     "ora.z_eventname": title,
                     "ora.z_email": email,
                     "ora.z_firstname": firstname,
                     "ora.z_lastname": lastname,
                     "ora.z_phone": mobilenumber,
                     "ora.z_state": state,
                     "ora.z_city": city,
                     "ora.z_pincode": pincode,
                   "ora.z_imgurl": imgurl,
                  }]
              };
        //console.log(payload);
        xmlhttp.open("POST", url);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(payload));
  //      setTimeout(triggerFunction, 12000);
    }
})();