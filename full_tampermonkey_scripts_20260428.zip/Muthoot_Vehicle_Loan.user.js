// ==UserScript==
// @name         Muthoot_Vehicle_Loan
// @namespace    http://tampermonkey.net/
// @version      2024-10-09
// @description  try to take over the world!
// @author       You
// @match        https://www.muthootfinance.com/custom-offers
// @icon         https://www.muthootfinance.com/sites/default/files/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    const element = document.getElementById("edit-submit");
    element.addEventListener("click", captureFunction);
    //window.ondblclick = function() {captureFunction()};

    function captureFunction() {
        const script = document.createElement('script');
        script.src = "https://d.oracleinfinity.io/infy/acs/account/8f18b0c3da08493b195f72e2f165b96a/js/perso_tag/odc.js";
        script.async = true;

        var cookie="muthootfinanceloan";
        var title = "muthootfinanceloan";
        var eventid = Date.now();
        var cname = document.querySelector("#edit-name-first").value;
        var cphone = document.querySelector("#edit-phone").value;
        var cloanamt = document.querySelector("#edit-loan-amount").value;
        var cvehicle = storevehicleValue();
        var cemployment = storeemploymentvalue();
        var ccouponcode = generateCouponCode();
        alert("Data Captured");
        script.onload = () => {
        // Code to execute after the script has loaded
        console.log('Script loaded successfully:');
        ORA.click({
                "sendSessionInfo": true,
                "data": {
                    "ora.z_eventname": "Triggervehicleloan",
                    "ora.z_tag": "Apply_for_loan",
                    "ora.z_cname": cname,
                    "ora.z_mobilephone": cphone,
                    "ora.z_expectedloanamount": cloanamt,
                    "ora.z_checked_in_date": cvehicle,
                    "ora.z_checked_out_date": cemployment,
                    "ora.z_eventid": eventid,
                    "ora.z_qrcode": ccouponcode
                }
            });
        };
        document.head.appendChild(script);

        //setTimeout(triggerFunction, 12000);
    }

    function triggerFunction() {
        //alert("on timer");
        var xmlhttp1 = new XMLHttpRequest(); // new HttpRequest instance
        var url1 = "https://dc.oracleinfinity.io/v3/8f18b0c3da08493b195f72e2f165b96a?dcsverbose=true";

        var payload = {
                "static": {
                "wt.co_f": "poonawallafincorp",
                "wt.ti": "poonawallafincorp",
               },
               "events": [{
                     "ora.z_eventname": "TriggerEventPWFC",
                     "ora.z_tag_id": "1",
                     "ora.z_email": "veerubravo@gmail.com"
                  }]
              };

        xmlhttp1.open("POST", url1);
        xmlhttp1.setRequestHeader("Content-Type", "application/json");
        xmlhttp1.send(JSON.stringify(payload));

    }
    function generateCouponCode() {
        //alert("in");
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let couponCode = '';
            for (let i = 0; i < 10; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                couponCode += characters.charAt(randomIndex);
            }

            return couponCode;
        }

    function storevehicleValue() {
      // Get all radio buttons with the name 'choice'
      const radioButtons = document.getElementsByName('type_of_vehicle');

      // Variable to store the selected value
      let selectedValue = null;

      // Loop through each radio button to find the checked one
      for (const radioButton of radioButtons) {
        if (radioButton.checked) {
          selectedValue = radioButton.value;
          break;
        }
      }
        return selectedValue;
    }

    function storeemploymentvalue() {
      // Get all radio buttons with the name 'choice'
      const radioButtons = document.getElementsByName('type_of_employment');

      // Variable to store the selected value
      let selectedValue = null;

      // Loop through each radio button to find the checked one
      for (const radioButton of radioButtons) {
        if (radioButton.checked) {
          selectedValue = radioButton.value;
          break;
        }
      }
        return selectedValue;
    }

})();