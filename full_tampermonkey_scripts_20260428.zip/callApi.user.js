// ==UserScript==
// @name         callApi
// @namespace    http://tampermonkey.net/
// @version      2024-03-14
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance
                var url = "https://login5.responsys.net/rest/api/v1.3/auth/token";
                var details = {
							'user_name': 'rakeshdemo028',
							'password': 'Rajesh@288apac',
							'auth_type': 'password'
						};

                var formBody = [];
                for (var property in details) {
                   var encodedKey = encodeURIComponent(property);
                   var encodedValue = encodeURIComponent(details[property]);
                   formBody.push(encodedKey + "=" + encodedValue);
                }
                formBody = formBody.join("&");
    alert(formBody);

                xmlhttp.open("POST", url);
                xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xmlhttp.send(formBody);
                alert(xmlhttp.responseText);

})();